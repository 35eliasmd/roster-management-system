import { auditLogs } from "@/db/schema";

export type AuditAction =
  | "USER_CREATED" | "USER_UPDATED" | "USER_DELETED"
  | "SHIFT_CREATED" | "SHIFT_UPDATED" | "SHIFT_DELETED"
  | "ROSTER_ASSIGNED" | "ROSTER_UPDATED" | "ROSTER_CANCELLED"
  | "SWAP_REQUESTED" | "SWAP_COUNTERPARTY_ACCEPTED" | "SWAP_COUNTERPARTY_REJECTED"
  | "SWAP_LEADER_APPROVED" | "SWAP_LEADER_REJECTED" | "SWAP_CANCELLED"
  | "ADMIN_OVERRIDE" | "LOB_CREATED" | "LOB_UPDATED" | "LOB_DELETED"
  | "SETTINGS_UPDATED" | "LOGIN_SUCCESS" | "LOGIN_FAILED";

export type EntityType = "USER" | "SHIFT" | "ROSTER" | "SWAP" | "LOB" | "SYSTEM";

interface WriteAuditParams {
  actorId: number | null;
  action: AuditAction;
  entityType: EntityType;
  entityId?: number | null;
  previousValue?: unknown;
  newValue?: unknown;
  description?: string;
}

/**
 * Insert an audit log row. Pass a `tx` (drizzle transaction) when this needs
 * to be atomic with the mutation it is describing so a crash can never leave
 * a data change unlogged.
 */
export async function writeAudit(
  tx: { insert: typeof import("@/db").db.insert },
  params: WriteAuditParams
) {
  await tx.insert(auditLogs).values({
    actorId: params.actorId,
    action: params.action,
    entityType: params.entityType,
    entityId: params.entityId ?? null,
    previousValue: params.previousValue ? JSON.parse(JSON.stringify(params.previousValue)) : null,
    newValue: params.newValue ? JSON.parse(JSON.stringify(params.newValue)) : null,
    description: params.description ?? null,
  });
}
