"use server";

import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import bcrypt from "bcryptjs";
import { requireUser } from "@/lib/session";
import { assertPermission, canManageUsers, isAdmin, isLeader } from "@/lib/permissions";
import { writeAudit } from "@/lib/audit";
import { revalidatePath } from "next/cache";

export async function createUser(input: {
  employeeId: string;
  name: string;
  email: string;
  password: string;
  role: "ADMIN" | "LEADER" | "USER";
  lobId?: number;
  reportingLeaderId?: number;
  designation?: string;
  phone?: string;
}) {
  const actor = await requireUser();
  assertPermission(canManageUsers(actor), "Only administrators can create users.");

  const passwordHash = await bcrypt.hash(input.password, 10);

  const [created] = await db
    .insert(users)
    .values({
      employeeId: input.employeeId,
      name: input.name,
      email: input.email.toLowerCase().trim(),
      passwordHash,
      role: input.role,
      lobId: input.lobId ?? null,
      reportingLeaderId: input.reportingLeaderId ?? null,
      designation: input.designation,
      phone: input.phone,
    })
    .returning();

  await writeAudit(db, {
    actorId: actor.id,
    action: "USER_CREATED",
    entityType: "USER",
    entityId: created.id,
    newValue: { ...created, passwordHash: undefined },
  });

  revalidatePath("/admin/users");
  return created;
}

export async function updateUser(input: {
  id: number;
  name?: string;
  email?: string;
  role?: "ADMIN" | "LEADER" | "USER";
  lobId?: number | null;
  reportingLeaderId?: number | null;
  status?: "ACTIVE" | "INACTIVE" | "SUSPENDED";
  designation?: string;
  phone?: string;
}) {
  const actor = await requireUser();
  assertPermission(canManageUsers(actor), "Only administrators can update users.");

  const [existing] = await db.select().from(users).where(eq(users.id, input.id)).limit(1);
  assertPermission(!!existing, "User not found.");

  const { id, ...patch } = input;
  const [updated] = await db
    .update(users)
    .set({ ...patch, updatedAt: new Date() })
    .where(eq(users.id, id))
    .returning();

  await writeAudit(db, {
    actorId: actor.id,
    action: "USER_UPDATED",
    entityType: "USER",
    entityId: id,
    previousValue: { ...existing, passwordHash: undefined },
    newValue: { ...updated, passwordHash: undefined },
  });

  revalidatePath("/admin/users");
  return updated;
}

export async function deleteUser(id: number) {
  const actor = await requireUser();
  assertPermission(canManageUsers(actor), "Only administrators can delete users.");
  assertPermission(actor.id !== id, "You cannot delete your own account.");

  const [existing] = await db.select().from(users).where(eq(users.id, id)).limit(1);
  assertPermission(!!existing, "User not found.");

  // Soft delete via status to preserve FK integrity & audit traceability
  const [updated] = await db
    .update(users)
    .set({ status: "INACTIVE", updatedAt: new Date() })
    .where(eq(users.id, id))
    .returning();

  await writeAudit(db, {
    actorId: actor.id,
    action: "USER_DELETED",
    entityType: "USER",
    entityId: id,
    previousValue: { ...existing, passwordHash: undefined },
    description: "User deactivated (soft delete) to preserve roster/audit history.",
  });

  revalidatePath("/admin/users");
  return updated;
}

/** List employees visible to the actor (Admin: all; Leader: subordinates; User: own LOB). */
export async function listVisibleUsers() {
  const actor = await requireUser();

  if (isAdmin(actor)) {
    return db.select().from(users);
  }
  if (isLeader(actor)) {
    return db.select().from(users).where(eq(users.reportingLeaderId, actor.id));
  }
  return db.select().from(users).where(eq(users.lobId, actor.lobId ?? -1));
}
