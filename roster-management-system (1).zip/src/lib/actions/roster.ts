"use server";

import { db } from "@/db";
import { rosterAssignments, rosterHistory, users, shifts } from "@/db/schema";
import { and, eq, gte, lte, inArray } from "drizzle-orm";
import { requireUser } from "@/lib/session";
import { assertPermission, canManageUser, isAdmin, isLeader } from "@/lib/permissions";
import { writeAudit } from "@/lib/audit";
import { notify } from "@/lib/notify";
import { revalidatePath } from "next/cache";

async function getTargetUser(userId: number) {
  const [u] = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  return u;
}

/** Assign a shift to an employee on a given date. Admin: any employee. Leader: only subordinates. */
export async function assignShift(input: {
  userId: number;
  shiftId: number;
  date: string; // YYYY-MM-DD
  notes?: string;
}) {
  const actor = await requireUser();
  const target = await getTargetUser(input.userId);
  assertPermission(!!target, "Employee not found.");
  assertPermission(
    canManageUser(actor, target!.id, target!.reportingLeaderId),
    "You are not authorized to assign shifts to this employee."
  );

  const result = await db.transaction(async (tx) => {
    // Conflict check: one active roster row per user/date (also enforced by DB unique index)
    const [existing] = await tx
      .select()
      .from(rosterAssignments)
      .where(and(eq(rosterAssignments.userId, input.userId), eq(rosterAssignments.date, input.date)))
      .limit(1);

    if (existing) {
      throw new Error(
        `${target!.name} already has a shift assigned on ${input.date}. Edit the existing assignment instead.`
      );
    }

    const [created] = await tx
      .insert(rosterAssignments)
      .values({
        userId: input.userId,
        shiftId: input.shiftId,
        date: input.date,
        notes: input.notes,
        assignedById: actor.id,
      })
      .returning();

    await tx.insert(rosterHistory).values({
      assignmentId: created.id,
      userId: input.userId,
      date: input.date,
      previousShiftId: null,
      newShiftId: input.shiftId,
      changeType: "CREATED",
      changedById: actor.id,
    });

    await writeAudit(tx, {
      actorId: actor.id,
      action: "ROSTER_ASSIGNED",
      entityType: "ROSTER",
      entityId: created.id,
      newValue: created,
      description: `${actor.name} assigned a shift to ${target!.name} on ${input.date}`,
    });

    await notify(tx, {
      userId: input.userId,
      type: "SHIFT_ASSIGNED",
      title: "New shift assigned",
      message: `You have been assigned a shift on ${input.date}.`,
      relatedAssignmentId: created.id,
    });

    return created;
  });

  revalidatePath("/roster");
  return result;
}

/** Directly change an employee's assigned shift for an existing roster row. */
export async function updateRosterAssignment(input: {
  assignmentId: number;
  newShiftId: number;
  reason?: string;
}) {
  const actor = await requireUser();

  const [existing] = await db
    .select()
    .from(rosterAssignments)
    .where(eq(rosterAssignments.id, input.assignmentId))
    .limit(1);
  assertPermission(!!existing, "Roster assignment not found.");

  const target = await getTargetUser(existing!.userId);
  assertPermission(
    canManageUser(actor, existing!.userId, target?.reportingLeaderId ?? null),
    "You are not authorized to modify this employee's roster."
  );

  const result = await db.transaction(async (tx) => {
    const [updated] = await tx
      .update(rosterAssignments)
      .set({ shiftId: input.newShiftId, updatedAt: new Date() })
      .where(eq(rosterAssignments.id, input.assignmentId))
      .returning();

    await tx.insert(rosterHistory).values({
      assignmentId: updated.id,
      userId: updated.userId,
      date: updated.date,
      previousShiftId: existing!.shiftId,
      newShiftId: input.newShiftId,
      changeType: "UPDATED",
      changedById: actor.id,
      reason: input.reason,
    });

    await writeAudit(tx, {
      actorId: actor.id,
      action: "ROSTER_UPDATED",
      entityType: "ROSTER",
      entityId: updated.id,
      previousValue: existing,
      newValue: updated,
    });

    await notify(tx, {
      userId: updated.userId,
      type: "ROSTER_CHANGED",
      title: "Your roster was updated",
      message: `Your shift on ${updated.date} was changed by ${actor.name}.`,
      relatedAssignmentId: updated.id,
    });

    return updated;
  });

  revalidatePath("/roster");
  return result;
}

/** Cancel/remove a roster assignment. */
export async function cancelRosterAssignment(assignmentId: number, reason?: string) {
  const actor = await requireUser();

  const [existing] = await db
    .select()
    .from(rosterAssignments)
    .where(eq(rosterAssignments.id, assignmentId))
    .limit(1);
  assertPermission(!!existing, "Roster assignment not found.");

  const target = await getTargetUser(existing!.userId);
  assertPermission(
    canManageUser(actor, existing!.userId, target?.reportingLeaderId ?? null),
    "You are not authorized to modify this employee's roster."
  );

  const result = await db.transaction(async (tx) => {
    const [updated] = await tx
      .update(rosterAssignments)
      .set({ status: "CANCELLED", updatedAt: new Date() })
      .where(eq(rosterAssignments.id, assignmentId))
      .returning();

    await tx.insert(rosterHistory).values({
      assignmentId: updated.id,
      userId: updated.userId,
      date: updated.date,
      previousShiftId: existing!.shiftId,
      newShiftId: existing!.shiftId,
      changeType: "CANCELLED",
      changedById: actor.id,
      reason,
    });

    await writeAudit(tx, {
      actorId: actor.id,
      action: "ROSTER_CANCELLED",
      entityType: "ROSTER",
      entityId: updated.id,
      previousValue: existing,
      newValue: updated,
    });

    await notify(tx, {
      userId: updated.userId,
      type: "SHIFT_CANCELLED",
      title: "Shift cancelled",
      message: `Your shift on ${updated.date} was cancelled by ${actor.name}.${reason ? " Reason: " + reason : ""}`,
      relatedAssignmentId: updated.id,
    });

    return updated;
  });

  revalidatePath("/roster");
  return result;
}

/** Fetch a specific employee's upcoming scheduled shifts (used to pick a swap counterparty's shift). */
export async function getUserScheduledAssignments(userId: number) {
  await requireUser();
  const today = new Date().toISOString().slice(0, 10);
  return db
    .select({ id: rosterAssignments.id, date: rosterAssignments.date, shiftName: shifts.name })
    .from(rosterAssignments)
    .innerJoin(shifts, eq(rosterAssignments.shiftId, shifts.id))
    .where(
      and(
        eq(rosterAssignments.userId, userId),
        eq(rosterAssignments.status, "SCHEDULED"),
        gte(rosterAssignments.date, today)
      )
    );
}

/** Roster listing with filters: date range, specific date, employeeId, name, lobId, shiftId. Scoped by role. */
export async function getRoster(filters: {
  from?: string;
  to?: string;
  employeeSearch?: string;
  lobId?: number;
  shiftId?: number;
}) {
  const actor = await requireUser();

  const conditions = [];
  if (filters.from) conditions.push(gte(rosterAssignments.date, filters.from));
  if (filters.to) conditions.push(lte(rosterAssignments.date, filters.to));
  if (filters.shiftId) conditions.push(eq(rosterAssignments.shiftId, filters.shiftId));

  // Scope by role: Admin sees all; Leader sees subordinates; User sees own LOB.
  let visibleUserIds: number[] | null = null;
  if (isLeader(actor)) {
    const subs = await db.select({ id: users.id }).from(users).where(eq(users.reportingLeaderId, actor.id));
    visibleUserIds = [actor.id, ...subs.map((s) => s.id)];
  } else if (!isAdmin(actor)) {
    const peers = await db.select({ id: users.id }).from(users).where(eq(users.lobId, actor.lobId ?? -1));
    visibleUserIds = peers.map((p) => p.id);
  }

  const rows = await db
    .select({
      id: rosterAssignments.id,
      date: rosterAssignments.date,
      status: rosterAssignments.status,
      notes: rosterAssignments.notes,
      userId: users.id,
      employeeId: users.employeeId,
      employeeName: users.name,
      lobId: users.lobId,
      shiftId: shifts.id,
      shiftName: shifts.name,
      shiftCode: shifts.code,
      startTime: shifts.startTime,
      endTime: shifts.endTime,
      colorHex: shifts.colorHex,
    })
    .from(rosterAssignments)
    .innerJoin(users, eq(rosterAssignments.userId, users.id))
    .innerJoin(shifts, eq(rosterAssignments.shiftId, shifts.id))
    .where(
      and(
        ...conditions,
        visibleUserIds ? inArray(rosterAssignments.userId, visibleUserIds) : undefined,
        filters.lobId ? eq(users.lobId, filters.lobId) : undefined
      )
    );

  let filtered = rows;
  if (filters.employeeSearch) {
    const q = filters.employeeSearch.toLowerCase();
    filtered = rows.filter(
      (r) => r.employeeName.toLowerCase().includes(q) || r.employeeId.toLowerCase().includes(q)
    );
  }

  return filtered;
}
