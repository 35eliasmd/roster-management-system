"use server";

import { db } from "@/db";
import { rosterAssignments, users, shifts, shiftSwapRequests } from "@/db/schema";
import { and, eq, gte, lte, sql, inArray, or } from "drizzle-orm";
import { requireUser } from "@/lib/session";
import { isAdmin, isLeader } from "@/lib/permissions";

/** Duty/shift counts per employee within a date range, scoped by role. */
export async function getDutyCounts(input: { from: string; to: string }) {
  const actor = await requireUser();

  let visibleUserIds: number[] | null = null;
  if (isLeader(actor)) {
    const subs = await db.select({ id: users.id }).from(users).where(eq(users.reportingLeaderId, actor.id));
    visibleUserIds = [actor.id, ...subs.map((s) => s.id)];
  } else if (!isAdmin(actor)) {
    const peers = await db.select({ id: users.id }).from(users).where(eq(users.lobId, actor.lobId ?? -1));
    visibleUserIds = peers.map((p) => p.id);
  }

  const rows = await db
    .select({
      userId: users.id,
      employeeId: users.employeeId,
      employeeName: users.name,
      shiftId: shifts.id,
      shiftName: shifts.name,
      count: sql<number>`count(*)`.as("count"),
    })
    .from(rosterAssignments)
    .innerJoin(users, eq(rosterAssignments.userId, users.id))
    .innerJoin(shifts, eq(rosterAssignments.shiftId, shifts.id))
    .where(
      and(
        gte(rosterAssignments.date, input.from),
        lte(rosterAssignments.date, input.to),
        eq(rosterAssignments.status, "SCHEDULED"),
        visibleUserIds ? inArray(rosterAssignments.userId, visibleUserIds) : undefined
      )
    )
    .groupBy(users.id, users.employeeId, users.name, shifts.id, shifts.name);

  return rows;
}

/** Dashboard summary numbers, scoped by role. */
export async function getDashboardSummary() {
  const actor = await requireUser();
  const today = new Date().toISOString().slice(0, 10);

  if (isAdmin(actor)) {
    const [{ count: totalEmployees }] = await db
      .select({ count: sql<number>`count(*)` })
      .from(users)
      .where(eq(users.role, "USER"));
    const [{ count: totalLeaders }] = await db
      .select({ count: sql<number>`count(*)` })
      .from(users)
      .where(eq(users.role, "LEADER"));
    const [{ count: pendingSwaps }] = await db
      .select({ count: sql<number>`count(*)` })
      .from(shiftSwapRequests)
      .where(
        or(
          eq(shiftSwapRequests.status, "PENDING_COUNTERPARTY"),
          eq(shiftSwapRequests.status, "PENDING_LEADER")
        )
      );
    const [{ count: todayShifts }] = await db
      .select({ count: sql<number>`count(*)` })
      .from(rosterAssignments)
      .where(and(eq(rosterAssignments.date, today), eq(rosterAssignments.status, "SCHEDULED")));

    return { role: "ADMIN" as const, totalEmployees, totalLeaders, pendingSwaps, todayShifts };
  }

  if (isLeader(actor)) {
    const subs = await db.select({ id: users.id }).from(users).where(eq(users.reportingLeaderId, actor.id));
    const subIds = subs.map((s) => s.id);

    const [{ count: todayShifts }] = subIds.length
      ? await db
          .select({ count: sql<number>`count(*)` })
          .from(rosterAssignments)
          .where(
            and(
              eq(rosterAssignments.date, today),
              eq(rosterAssignments.status, "SCHEDULED"),
              inArray(rosterAssignments.userId, subIds)
            )
          )
      : [{ count: 0 }];

    const [{ count: pendingApprovals }] = await db
      .select({ count: sql<number>`count(*)` })
      .from(shiftSwapRequests)
      .where(and(eq(shiftSwapRequests.status, "PENDING_LEADER"), eq(shiftSwapRequests.leaderId, actor.id)));

    return { role: "LEADER" as const, subordinateCount: subIds.length, todayShifts, pendingApprovals };
  }

  // USER
  const [todayAssignment] = await db
    .select({ shiftName: shifts.name, startTime: shifts.startTime, endTime: shifts.endTime })
    .from(rosterAssignments)
    .innerJoin(shifts, eq(rosterAssignments.shiftId, shifts.id))
    .where(and(eq(rosterAssignments.userId, actor.id), eq(rosterAssignments.date, today)))
    .limit(1);

  const [{ count: pendingIncoming }] = await db
    .select({ count: sql<number>`count(*)` })
    .from(shiftSwapRequests)
    .where(and(eq(shiftSwapRequests.counterpartyId, actor.id), eq(shiftSwapRequests.status, "PENDING_COUNTERPARTY")));

  return { role: "USER" as const, todayShift: todayAssignment ?? null, pendingIncoming };
}
