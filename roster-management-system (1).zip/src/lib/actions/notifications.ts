"use server";

import { db } from "@/db";
import { notifications, auditLogs, users } from "@/db/schema";
import { and, eq, desc } from "drizzle-orm";
import { requireUser } from "@/lib/session";
import { assertPermission, isAdmin } from "@/lib/permissions";
import { revalidatePath } from "next/cache";

export async function listMyNotifications() {
  const actor = await requireUser();
  return db
    .select()
    .from(notifications)
    .where(eq(notifications.userId, actor.id))
    .orderBy(desc(notifications.createdAt))
    .limit(50);
}

export async function markNotificationRead(id: number) {
  const actor = await requireUser();
  const [existing] = await db.select().from(notifications).where(eq(notifications.id, id)).limit(1);
  assertPermission(!!existing, "Notification not found.");
  assertPermission(existing!.userId === actor.id, "You cannot modify another user's notifications.");

  await db.update(notifications).set({ isRead: true }).where(eq(notifications.id, id));
  revalidatePath("/notifications");
}

/** Admin: full audit log. Leader: entries related to their scope only (simplified: entries they authored + roster/swap entries for their subordinates). */
export async function listAuditLogs(limit = 100) {
  const actor = await requireUser();
  assertPermission(isAdmin(actor), "Only administrators can view the full system audit log.");

  return db
    .select({
      id: auditLogs.id,
      action: auditLogs.action,
      entityType: auditLogs.entityType,
      entityId: auditLogs.entityId,
      description: auditLogs.description,
      previousValue: auditLogs.previousValue,
      newValue: auditLogs.newValue,
      createdAt: auditLogs.createdAt,
      actorName: users.name,
      actorEmployeeId: users.employeeId,
    })
    .from(auditLogs)
    .leftJoin(users, eq(auditLogs.actorId, users.id))
    .orderBy(desc(auditLogs.createdAt))
    .limit(limit);
}
