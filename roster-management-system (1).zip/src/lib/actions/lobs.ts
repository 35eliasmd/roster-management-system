"use server";

import { db } from "@/db";
import { lobs } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requireUser } from "@/lib/session";
import { assertPermission, canManageLobs } from "@/lib/permissions";
import { writeAudit } from "@/lib/audit";
import { revalidatePath } from "next/cache";

export async function createLob(input: { name: string; code: string; description?: string }) {
  const actor = await requireUser();
  assertPermission(canManageLobs(actor), "Only administrators can create LOB/Team groups.");

  const [created] = await db.insert(lobs).values(input).returning();

  await writeAudit(db, {
    actorId: actor.id,
    action: "LOB_CREATED",
    entityType: "LOB",
    entityId: created.id,
    newValue: created,
  });

  revalidatePath("/admin/lobs");
  return created;
}

export async function updateLob(input: { id: number; name?: string; description?: string; isActive?: boolean }) {
  const actor = await requireUser();
  assertPermission(canManageLobs(actor), "Only administrators can edit LOB/Team groups.");

  const [existing] = await db.select().from(lobs).where(eq(lobs.id, input.id)).limit(1);
  assertPermission(!!existing, "LOB not found.");

  const { id, ...patch } = input;
  const [updated] = await db
    .update(lobs)
    .set({ ...patch, updatedAt: new Date() })
    .where(eq(lobs.id, id))
    .returning();

  await writeAudit(db, {
    actorId: actor.id,
    action: "LOB_UPDATED",
    entityType: "LOB",
    entityId: id,
    previousValue: existing,
    newValue: updated,
  });

  revalidatePath("/admin/lobs");
  return updated;
}

export async function listLobs() {
  await requireUser();
  return db.select().from(lobs);
}
