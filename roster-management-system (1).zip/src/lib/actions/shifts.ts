"use server";

import { db } from "@/db";
import { shifts } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requireUser } from "@/lib/session";
import { assertPermission, canManageShiftCatalog } from "@/lib/permissions";
import { writeAudit } from "@/lib/audit";
import { revalidatePath } from "next/cache";

export async function createShift(input: {
  name: string;
  code: string;
  startTime: string; // HH:MM
  endTime: string;
  isOvernight?: boolean;
  colorHex?: string;
  description?: string;
}) {
  const actor = await requireUser();
  assertPermission(canManageShiftCatalog(actor), "Only administrators can create shifts.");

  const [created] = await db.insert(shifts).values(input).returning();

  await writeAudit(db, {
    actorId: actor.id,
    action: "SHIFT_CREATED",
    entityType: "SHIFT",
    entityId: created.id,
    newValue: created,
  });

  revalidatePath("/admin/shifts");
  return created;
}

export async function updateShift(input: {
  id: number;
  name?: string;
  startTime?: string;
  endTime?: string;
  isOvernight?: boolean;
  colorHex?: string;
  description?: string;
  isActive?: boolean;
}) {
  const actor = await requireUser();
  assertPermission(canManageShiftCatalog(actor), "Only administrators can edit shifts.");

  const [existing] = await db.select().from(shifts).where(eq(shifts.id, input.id)).limit(1);
  assertPermission(!!existing, "Shift not found.");

  const { id, ...patch } = input;
  const [updated] = await db
    .update(shifts)
    .set({ ...patch, updatedAt: new Date() })
    .where(eq(shifts.id, id))
    .returning();

  await writeAudit(db, {
    actorId: actor.id,
    action: "SHIFT_UPDATED",
    entityType: "SHIFT",
    entityId: id,
    previousValue: existing,
    newValue: updated,
  });

  revalidatePath("/admin/shifts");
  return updated;
}

export async function deleteShift(id: number) {
  const actor = await requireUser();
  assertPermission(canManageShiftCatalog(actor), "Only administrators can delete shifts.");

  const [existing] = await db.select().from(shifts).where(eq(shifts.id, id)).limit(1);
  assertPermission(!!existing, "Shift not found.");

  // Soft delete (deactivate) - roster history may still reference this shift
  const [updated] = await db
    .update(shifts)
    .set({ isActive: false, updatedAt: new Date() })
    .where(eq(shifts.id, id))
    .returning();

  await writeAudit(db, {
    actorId: actor.id,
    action: "SHIFT_DELETED",
    entityType: "SHIFT",
    entityId: id,
    previousValue: existing,
    description: "Shift deactivated (soft delete) to preserve roster history integrity.",
  });

  revalidatePath("/admin/shifts");
  return updated;
}

export async function listShifts() {
  await requireUser();
  return db.select().from(shifts);
}
