"use server";

import { db } from "@/db";
import { rosterAssignments, shiftSwapRequests, users, rosterHistory } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { requireUser } from "@/lib/session";
import { assertPermission, canApproveSwap, isAdmin } from "@/lib/permissions";
import { writeAudit } from "@/lib/audit";
import { notify } from "@/lib/notify";
import { revalidatePath } from "next/cache";

/* ------------------------------------------------------------------ */
/* STEP 1 — Employee A creates a swap request                          */
/* ------------------------------------------------------------------ */

export async function createSwapRequest(input: {
  requesterAssignmentId: number;
  counterpartyId: number;
  counterpartyAssignmentId: number;
  reason?: string;
}) {
  const actor = await requireUser();

  const [requesterAssignment] = await db
    .select()
    .from(rosterAssignments)
    .where(eq(rosterAssignments.id, input.requesterAssignmentId))
    .limit(1);

  assertPermission(!!requesterAssignment, "Your shift assignment could not be found.");
  assertPermission(
    requesterAssignment!.userId === actor.id || isAdmin(actor),
    "You can only offer your own shift for a swap."
  );

  const [counterpartyAssignment] = await db
    .select()
    .from(rosterAssignments)
    .where(eq(rosterAssignments.id, input.counterpartyAssignmentId))
    .limit(1);

  assertPermission(!!counterpartyAssignment, "The selected employee's shift could not be found.");
  assertPermission(
    counterpartyAssignment!.userId === input.counterpartyId,
    "Selected shift does not belong to the selected employee."
  );
  assertPermission(
    counterpartyAssignment!.userId !== actor.id,
    "You cannot request a swap with yourself."
  );
  assertPermission(
    requesterAssignment!.status === "SCHEDULED" && counterpartyAssignment!.status === "SCHEDULED",
    "Both shifts must be active (scheduled) to be swapped."
  );

  const [row] = await db
    .insert(shiftSwapRequests)
    .values({
      requesterId: actor.id,
      requesterAssignmentId: input.requesterAssignmentId,
      counterpartyId: input.counterpartyId,
      counterpartyAssignmentId: input.counterpartyAssignmentId,
      reason: input.reason,
      status: "PENDING_COUNTERPARTY",
    })
    .returning();

  await writeAudit(db, {
    actorId: actor.id,
    action: "SWAP_REQUESTED",
    entityType: "SWAP",
    entityId: row.id,
    newValue: row,
    description: `${actor.name} requested a shift swap with user #${input.counterpartyId}`,
  });

  await notify(db, {
    userId: input.counterpartyId,
    type: "SWAP_REQUESTED",
    title: "New shift swap request",
    message: `${actor.name} has requested to swap shifts with you on ${requesterAssignment!.date}.`,
    relatedSwapId: row.id,
  });

  revalidatePath("/swaps");
  return row;
}

/* ------------------------------------------------------------------ */
/* STEP 2 — Employee B accepts or rejects                              */
/* ------------------------------------------------------------------ */

export async function respondToSwapAsCounterparty(input: {
  swapId: number;
  accept: boolean;
}) {
  const actor = await requireUser();

  const [swap] = await db
    .select()
    .from(shiftSwapRequests)
    .where(eq(shiftSwapRequests.id, input.swapId))
    .limit(1);

  assertPermission(!!swap, "Swap request not found.");
  assertPermission(
    swap!.counterpartyId === actor.id || isAdmin(actor),
    "Only the invited employee can respond to this swap request."
  );
  assertPermission(
    swap!.status === "PENDING_COUNTERPARTY",
    "This request is no longer awaiting your response."
  );

  // Resolve the requester's leader (approval is routed to them next)
  const [requester] = await db.select().from(users).where(eq(users.id, swap!.requesterId)).limit(1);

  const newStatus = input.accept ? "PENDING_LEADER" : "REJECTED_BY_COUNTERPARTY";

  const [updated] = await db
    .update(shiftSwapRequests)
    .set({
      status: newStatus,
      counterpartyRespondedAt: new Date(),
      counterpartyRespondedById: actor.id,
      leaderId: input.accept ? requester?.reportingLeaderId ?? null : null,
      updatedAt: new Date(),
    })
    .where(eq(shiftSwapRequests.id, input.swapId))
    .returning();

  await writeAudit(db, {
    actorId: actor.id,
    action: input.accept ? "SWAP_COUNTERPARTY_ACCEPTED" : "SWAP_COUNTERPARTY_REJECTED",
    entityType: "SWAP",
    entityId: swap!.id,
    previousValue: swap,
    newValue: updated,
  });

  await notify(db, {
    userId: swap!.requesterId,
    type: input.accept ? "SWAP_COUNTERPARTY_ACCEPTED" : "SWAP_COUNTERPARTY_REJECTED",
    title: input.accept ? "Swap accepted — pending leader approval" : "Swap request rejected",
    message: input.accept
      ? `${actor.name} accepted your swap request. It now awaits leader approval.`
      : `${actor.name} rejected your swap request.`,
    relatedSwapId: swap!.id,
  });

  if (input.accept && requester?.reportingLeaderId) {
    await notify(db, {
      userId: requester.reportingLeaderId,
      type: "SWAP_REQUESTED",
      title: "Shift swap awaiting your approval",
      message: `A shift swap between ${requester.name} and another employee needs your approval.`,
      relatedSwapId: swap!.id,
    });
  }

  revalidatePath("/swaps");
  return updated;
}

/* ------------------------------------------------------------------ */
/* STEP 3 — Leader (or Admin override) approves/rejects                */
/* STEP 4 — Roster update happens atomically on approval               */
/* ------------------------------------------------------------------ */

export async function decideSwapAsLeader(input: {
  swapId: number;
  approve: boolean;
  comment?: string;
}) {
  const actor = await requireUser();

  const [swap] = await db
    .select()
    .from(shiftSwapRequests)
    .where(eq(shiftSwapRequests.id, input.swapId))
    .limit(1);

  assertPermission(!!swap, "Swap request not found.");
  assertPermission(
    swap!.status === "PENDING_LEADER",
    "This request is not awaiting leader approval."
  );
  assertPermission(
    canApproveSwap(actor, swap!.leaderId),
    "You are not authorized to approve this swap."
  );

  if (!input.approve) {
    const [updated] = await db
      .update(shiftSwapRequests)
      .set({
        status: "REJECTED_BY_LEADER",
        leaderRespondedAt: new Date(),
        leaderRespondedById: actor.id,
        leaderComment: input.comment,
        isAdminOverride: isAdmin(actor) && swap!.leaderId !== actor.id,
        updatedAt: new Date(),
      })
      .where(eq(shiftSwapRequests.id, input.swapId))
      .returning();

    await writeAudit(db, {
      actorId: actor.id,
      action: "SWAP_LEADER_REJECTED",
      entityType: "SWAP",
      entityId: swap!.id,
      previousValue: swap,
      newValue: updated,
    });

    for (const uid of [swap!.requesterId, swap!.counterpartyId]) {
      await notify(db, {
        userId: uid,
        type: "SWAP_LEADER_REJECTED",
        title: "Shift swap rejected by leader",
        message: `Your shift swap request was rejected by the leader.${input.comment ? " Reason: " + input.comment : ""}`,
        relatedSwapId: swap!.id,
      });
    }

    revalidatePath("/swaps");
    return updated;
  }

  // APPROVAL: swap the two assignments' shifts atomically, update history, notify.
  const result = await db.transaction(async (tx) => {
    const [reqAssignment] = await tx
      .select()
      .from(rosterAssignments)
      .where(eq(rosterAssignments.id, swap!.requesterAssignmentId))
      .limit(1);
    const [cpAssignment] = await tx
      .select()
      .from(rosterAssignments)
      .where(eq(rosterAssignments.id, swap!.counterpartyAssignmentId))
      .limit(1);

    if (!reqAssignment || !cpAssignment) {
      throw new Error("One or both roster assignments no longer exist.");
    }
    if (reqAssignment.status !== "SCHEDULED" || cpAssignment.status !== "SCHEDULED") {
      throw new Error("One or both shifts are no longer active; cannot complete swap.");
    }

    const reqPrevShiftId = reqAssignment.shiftId;
    const cpPrevShiftId = cpAssignment.shiftId;

    // Swap the shiftId (and owning user stays the same date-slot; the SHIFT changes hands)
    await tx
      .update(rosterAssignments)
      .set({ shiftId: cpPrevShiftId, updatedAt: new Date() })
      .where(eq(rosterAssignments.id, reqAssignment.id));

    await tx
      .update(rosterAssignments)
      .set({ shiftId: reqPrevShiftId, updatedAt: new Date() })
      .where(eq(rosterAssignments.id, cpAssignment.id));

    await tx.insert(rosterHistory).values([
      {
        assignmentId: reqAssignment.id,
        userId: reqAssignment.userId,
        date: reqAssignment.date,
        previousShiftId: reqPrevShiftId,
        newShiftId: cpPrevShiftId,
        changeType: "SWAPPED",
        changedById: actor.id,
        reason: `Shift swap #${swap!.id} approved`,
      },
      {
        assignmentId: cpAssignment.id,
        userId: cpAssignment.userId,
        date: cpAssignment.date,
        previousShiftId: cpPrevShiftId,
        newShiftId: reqPrevShiftId,
        changeType: "SWAPPED",
        changedById: actor.id,
        reason: `Shift swap #${swap!.id} approved`,
      },
    ]);

    const [updatedSwap] = await tx
      .update(shiftSwapRequests)
      .set({
        status: "APPROVED",
        leaderRespondedAt: new Date(),
        leaderRespondedById: actor.id,
        leaderComment: input.comment,
        isAdminOverride: isAdmin(actor) && swap!.leaderId !== actor.id,
        updatedAt: new Date(),
      })
      .where(eq(shiftSwapRequests.id, input.swapId))
      .returning();

    await writeAudit(tx, {
      actorId: actor.id,
      action: "SWAP_LEADER_APPROVED",
      entityType: "SWAP",
      entityId: swap!.id,
      previousValue: swap,
      newValue: updatedSwap,
      description: `Roster updated: shift swap #${swap!.id} completed.`,
    });

    for (const uid of [swap!.requesterId, swap!.counterpartyId]) {
      await notify(tx, {
        userId: uid,
        type: "SWAP_LEADER_APPROVED",
        title: "Shift swap approved",
        message: "Your shift swap has been approved and the roster has been updated.",
        relatedSwapId: swap!.id,
      });
    }

    return updatedSwap;
  });

  revalidatePath("/swaps");
  revalidatePath("/roster");
  return result;
}

/* ------------------------------------------------------------------ */
/* Cancel / Admin override                                             */
/* ------------------------------------------------------------------ */

export async function cancelSwapRequest(swapId: number) {
  const actor = await requireUser();

  const [swap] = await db.select().from(shiftSwapRequests).where(eq(shiftSwapRequests.id, swapId)).limit(1);
  assertPermission(!!swap, "Swap request not found.");
  assertPermission(
    swap!.requesterId === actor.id || isAdmin(actor),
    "Only the requester or an administrator can cancel this request."
  );
  assertPermission(
    swap!.status === "PENDING_COUNTERPARTY" || swap!.status === "PENDING_LEADER",
    "Only pending requests can be cancelled."
  );

  const [updated] = await db
    .update(shiftSwapRequests)
    .set({ status: "CANCELLED", updatedAt: new Date(), isAdminOverride: isAdmin(actor) && swap!.requesterId !== actor.id })
    .where(eq(shiftSwapRequests.id, swapId))
    .returning();

  await writeAudit(db, {
    actorId: actor.id,
    action: isAdmin(actor) && swap!.requesterId !== actor.id ? "ADMIN_OVERRIDE" : "SWAP_CANCELLED",
    entityType: "SWAP",
    entityId: swapId,
    previousValue: swap,
    newValue: updated,
  });

  revalidatePath("/swaps");
  return updated;
}
