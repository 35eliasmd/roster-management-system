import { auth } from "@/auth";
import type { SessionUser } from "@/lib/permissions";

/** Get the current logged-in user on the server, or throw if not authenticated. */
export async function requireUser(): Promise<SessionUser> {
  const session = await auth();
  if (!session?.user) {
    throw new Error("UNAUTHENTICATED");
  }
  return session.user as SessionUser;
}
