import { notifications } from "@/db/schema";

type NotificationType =
  | "SWAP_REQUESTED" | "SWAP_COUNTERPARTY_ACCEPTED" | "SWAP_COUNTERPARTY_REJECTED"
  | "SWAP_LEADER_APPROVED" | "SWAP_LEADER_REJECTED"
  | "ROSTER_CHANGED" | "SHIFT_ASSIGNED" | "SHIFT_CANCELLED" | "SYSTEM";

interface NotifyParams {
  userId: number;
  type: NotificationType;
  title: string;
  message: string;
  relatedSwapId?: number;
  relatedAssignmentId?: number;
}

/** Insert an in-app notification row. Pass `tx` to keep it atomic with the triggering change. */
export async function notify(
  tx: { insert: typeof import("@/db").db.insert },
  params: NotifyParams
) {
  await tx.insert(notifications).values({
    userId: params.userId,
    type: params.type,
    title: params.title,
    message: params.message,
    relatedSwapId: params.relatedSwapId ?? null,
    relatedAssignmentId: params.relatedAssignmentId ?? null,
  });
}
