/**
 * Central RBAC module.
 *
 * IMPORTANT: These checks MUST be re-run on every server action / API route.
 * Never trust the client. UI hiding of buttons/links is a convenience only.
 */

export type Role = "ADMIN" | "LEADER" | "USER";

export interface SessionUser {
  id: number;
  employeeId: string;
  name: string;
  email: string;
  role: Role;
  lobId: number | null;
  reportingLeaderId: number | null;
}

/** Basic role gates */
export const isAdmin = (u: SessionUser) => u.role === "ADMIN";
export const isLeader = (u: SessionUser) => u.role === "LEADER";
export const isAdminOrLeader = (u: SessionUser) => u.role === "ADMIN" || u.role === "LEADER";

/**
 * Determines whether `actor` is allowed to manage (assign shifts / edit roster
 * / approve swaps for) `targetUserId`.
 *
 * - Admin: always allowed.
 * - Leader: allowed only for their direct subordinates (reportingLeaderId === actor.id).
 * - User: never allowed to manage others.
 *
 * `subordinateLeaderId` should be looked up from the DB (the target user's
 * reportingLeaderId) by the caller and passed in here.
 */
export function canManageUser(
  actor: SessionUser,
  targetUserId: number,
  targetReportingLeaderId: number | null
): boolean {
  if (isAdmin(actor)) return true;
  if (isLeader(actor)) return targetReportingLeaderId === actor.id;
  return actor.id === targetUserId; // users can "manage" (view/edit) only themselves, and only where explicitly allowed
}

/**
 * Determines whether `actor` may view roster rows belonging to `targetLobId`.
 * - Admin: all LOBs.
 * - Leader: their subordinates' LOB(s) - simplified here to "own LOB" plus any
 *   subordinate LOB should be resolved via DB query in the calling code.
 * - User: only their own LOB.
 */
export function canViewLob(actor: SessionUser, targetLobId: number | null): boolean {
  if (isAdmin(actor)) return true;
  if (targetLobId === null) return false;
  return actor.lobId === targetLobId;
}

/** Only Admin can manage users, shifts (create/delete), LOBs, and system settings. */
export const canManageUsers = (actor: SessionUser) => isAdmin(actor);
export const canManageShiftCatalog = (actor: SessionUser) => isAdmin(actor);
export const canManageLobs = (actor: SessionUser) => isAdmin(actor);
export const canManageSystemSettings = (actor: SessionUser) => isAdmin(actor);

/** Admin + Leader can assign shifts / edit rosters (Leader restricted to own subordinates). */
export const canAssignShifts = (actor: SessionUser) => isAdminOrLeader(actor);

/** Admin can override/approve any swap; Leader can approve swaps for their subordinates only. */
export function canApproveSwap(
  actor: SessionUser,
  requesterLeaderId: number | null
): boolean {
  if (isAdmin(actor)) return true;
  if (isLeader(actor)) return requesterLeaderId === actor.id;
  return false;
}

export class ForbiddenError extends Error {
  constructor(message = "You do not have permission to perform this action.") {
    super(message);
    this.name = "ForbiddenError";
  }
}

/** Throws ForbiddenError if condition is false. Use at the top of every server action. */
export function assertPermission(condition: boolean, message?: string): void {
  if (!condition) throw new ForbiddenError(message);
}
