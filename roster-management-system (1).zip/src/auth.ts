import NextAuth from "next-auth";
import Credentials from "next-auth/providers/credentials";
import bcrypt from "bcryptjs";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import type { Role } from "@/lib/permissions";

export const { handlers, signIn, signOut, auth } = NextAuth({
  session: { strategy: "jwt" },
  pages: {
    signIn: "/login",
  },
  providers: [
    Credentials({
      name: "Credentials",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" },
      },
      authorize: async (credentials) => {
        const email = (credentials?.email as string)?.toLowerCase().trim();
        const password = credentials?.password as string;
        if (!email || !password) return null;

        const [user] = await db
          .select()
          .from(users)
          .where(eq(users.email, email))
          .limit(1);

        if (!user) return null;
        if (user.status !== "ACTIVE") return null;

        const valid = await bcrypt.compare(password, user.passwordHash);
        if (!valid) return null;

        return {
          id: String(user.id),
          employeeId: user.employeeId,
          name: user.name,
          email: user.email,
          role: user.role,
          lobId: user.lobId,
          reportingLeaderId: user.reportingLeaderId,
        };
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        const u = user as unknown as {
          id: string;
          employeeId: string;
          role: Role;
          lobId: number | null;
          reportingLeaderId: number | null;
        };
        token.id = u.id;
        token.employeeId = u.employeeId;
        token.role = u.role;
        token.lobId = u.lobId;
        token.reportingLeaderId = u.reportingLeaderId;
      }
      return token;
    },
    async session({ session, token }) {
      if (session.user) {
        // next-auth v5 beta's Session["user"] type, once augmented via
        // @auth/core/types, resolves through multiple merged declarations
        // in a way tsc cannot cleanly narrow. The runtime shape is correct
        // and matches src/types/next-auth.d.ts; this single cast is scoped
        // to that known beta typing gap only.
        session.user = {
          id: Number(token.id),
          employeeId: token.employeeId,
          name: session.user.name,
          email: session.user.email,
          role: token.role,
          lobId: token.lobId,
          reportingLeaderId: token.reportingLeaderId,
        } as unknown as typeof session.user;
      }
      return session;
    },
  },
});
