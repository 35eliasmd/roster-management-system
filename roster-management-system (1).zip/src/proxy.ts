import { auth } from "@/auth";
import { NextResponse } from "next/server";

// Route prefixes restricted to specific roles.
// Middleware is a FIRST layer of defense (fast redirect for UX).
// The real enforcement always happens again in server actions / API routes.
const ADMIN_ONLY = ["/admin"];
const ADMIN_OR_LEADER = ["/leader", "/manage"];

export default auth((req) => {
  const { nextUrl } = req;
  const isLoggedIn = !!req.auth;
  const role = req.auth?.user?.role;

  const isPublic =
    nextUrl.pathname === "/login" ||
    nextUrl.pathname.startsWith("/api/auth");

  if (isPublic) return NextResponse.next();

  if (!isLoggedIn) {
    const loginUrl = new URL("/login", nextUrl);
    loginUrl.searchParams.set("callbackUrl", nextUrl.pathname);
    return NextResponse.redirect(loginUrl);
  }

  if (
    ADMIN_ONLY.some((p) => nextUrl.pathname.startsWith(p)) &&
    role !== "ADMIN"
  ) {
    return NextResponse.redirect(new URL("/dashboard?error=forbidden", nextUrl));
  }

  if (
    ADMIN_OR_LEADER.some((p) => nextUrl.pathname.startsWith(p)) &&
    role !== "ADMIN" &&
    role !== "LEADER"
  ) {
    return NextResponse.redirect(new URL("/dashboard?error=forbidden", nextUrl));
  }

  return NextResponse.next();
});

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico|.*\\.png$).*)"],
};
