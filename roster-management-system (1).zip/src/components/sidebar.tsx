import Link from "next/link";
import { SessionUser } from "@/lib/permissions";
import { SignOutButton } from "./sign-out-button";
import {
  LayoutDashboard,
  CalendarDays,
  Repeat,
  Users,
  Clock,
  Building2,
  ScrollText,
  Bell,
} from "lucide-react";

export function Sidebar({ user }: { user: SessionUser }) {
  const links = [
    { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard, roles: ["ADMIN", "LEADER", "USER"] },
    { href: "/roster", label: "Roster", icon: CalendarDays, roles: ["ADMIN", "LEADER", "USER"] },
    { href: "/swaps", label: "Shift Swaps", icon: Repeat, roles: ["ADMIN", "LEADER", "USER"] },
    { href: "/notifications", label: "Notifications", icon: Bell, roles: ["ADMIN", "LEADER", "USER"] },
    { href: "/admin/users", label: "Users", icon: Users, roles: ["ADMIN"] },
    { href: "/admin/shifts", label: "Shift Catalog", icon: Clock, roles: ["ADMIN"] },
    { href: "/admin/lobs", label: "LOB / Teams", icon: Building2, roles: ["ADMIN"] },
    { href: "/admin/audit-logs", label: "Audit Log", icon: ScrollText, roles: ["ADMIN"] },
  ];

  return (
    <aside
      className="w-64 shrink-0 flex flex-col h-screen sticky top-0 text-white"
      style={{ background: "var(--harbor-deep)" }}
    >
      <div className="p-5 flex items-center gap-2 border-b border-white/10">
        <div
          className="w-8 h-8 rounded-md flex items-center justify-center shrink-0"
          style={{ background: "var(--amber)" }}
        >
          <span className="font-bold text-sm">R</span>
        </div>
        <div className="leading-tight">
          <p className="font-semibold text-sm">Roster Mgmt</p>
          <p className="text-xs text-white/50">{user.role}</p>
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-1">
        {links
          .filter((l) => l.roles.includes(user.role))
          .map((l) => {
            const Icon = l.icon;
            return (
              <Link
                key={l.href}
                href={l.href}
                className="flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium text-white/80 hover:bg-white/10 hover:text-white transition-colors"
              >
                <Icon size={17} />
                {l.label}
              </Link>
            );
          })}
      </nav>

      <div className="p-4 border-t border-white/10">
        <p className="text-sm font-medium truncate">{user.name}</p>
        <p className="text-xs text-white/50 truncate mb-3">{user.email}</p>
        <SignOutButton />
      </div>
    </aside>
  );
}
