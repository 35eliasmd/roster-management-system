"use client";

import { signOut } from "next-auth/react";
import { LogOut } from "lucide-react";

export function SignOutButton() {
  return (
    <button
      onClick={() => signOut({ callbackUrl: "/login" })}
      className="flex items-center gap-2 text-sm text-white/70 hover:text-white transition-colors"
    >
      <LogOut size={15} />
      Sign out
    </button>
  );
}
