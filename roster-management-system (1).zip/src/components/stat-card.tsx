export function StatCard({
  label,
  value,
  accent,
}: {
  label: string;
  value: number;
  accent?: "amber" | "teal";
}) {
  const color = accent === "amber" ? "var(--amber)" : accent === "teal" ? "var(--teal)" : "var(--ink)";
  return (
    <div className="card p-5">
      <p className="text-sm font-medium mb-2" style={{ color: "var(--ink-soft)" }}>
        {label}
      </p>
      <p className="text-3xl font-semibold" style={{ color }}>
        {value}
      </p>
    </div>
  );
}
