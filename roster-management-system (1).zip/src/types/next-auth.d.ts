import { Role } from "@/lib/permissions";

declare module "@auth/core/types" {
  interface Session {
    user: {
      id: number;
      employeeId: string;
      name: string;
      email: string;
      role: Role;
      lobId: number | null;
      reportingLeaderId: number | null;
    };
  }

  interface User {
    id: string;
    employeeId: string;
    role: Role;
    lobId: number | null;
    reportingLeaderId: number | null;
  }
}

declare module "@auth/core/jwt" {
  interface JWT {
    id: string;
    employeeId: string;
    role: Role;
    lobId: number | null;
    reportingLeaderId: number | null;
  }
}
