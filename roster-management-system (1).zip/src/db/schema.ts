import {
  pgTable,
  serial,
  text,
  varchar,
  timestamp,
  integer,
  boolean,
  pgEnum,
  date,
  time,
  jsonb,
  uniqueIndex,
  index,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";

/* ------------------------------------------------------------------ */
/*  ENUMS                                                              */
/* ------------------------------------------------------------------ */

export const roleEnum = pgEnum("role", ["ADMIN", "LEADER", "USER"]);

export const accountStatusEnum = pgEnum("account_status", [
  "ACTIVE",
  "INACTIVE",
  "SUSPENDED",
]);

export const swapStatusEnum = pgEnum("swap_status", [
  "PENDING_COUNTERPARTY", // waiting on Employee B
  "PENDING_LEADER", // B accepted, waiting on leader
  "APPROVED", // leader approved -> roster updated
  "REJECTED_BY_COUNTERPARTY",
  "REJECTED_BY_LEADER",
  "CANCELLED", // cancelled by requester or admin override
]);

export const assignmentStatusEnum = pgEnum("assignment_status", [
  "SCHEDULED",
  "CANCELLED",
  "COMPLETED",
]);

export const notificationTypeEnum = pgEnum("notification_type", [
  "SWAP_REQUESTED",
  "SWAP_COUNTERPARTY_ACCEPTED",
  "SWAP_COUNTERPARTY_REJECTED",
  "SWAP_LEADER_APPROVED",
  "SWAP_LEADER_REJECTED",
  "ROSTER_CHANGED",
  "SHIFT_ASSIGNED",
  "SHIFT_CANCELLED",
  "SYSTEM",
]);

/* ------------------------------------------------------------------ */
/*  ORGANIZATION: LOB / TEAM / GROUP                                   */
/* ------------------------------------------------------------------ */

export const lobs = pgTable("lobs", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 120 }).notNull(),
  code: varchar("code", { length: 40 }).notNull(),
  description: text("description"),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  codeUnique: uniqueIndex("lobs_code_unique").on(t.code),
}));

/* ------------------------------------------------------------------ */
/*  USERS                                                              */
/* ------------------------------------------------------------------ */

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  employeeId: varchar("employee_id", { length: 40 }).notNull(),
  name: varchar("name", { length: 160 }).notNull(),
  email: varchar("email", { length: 200 }).notNull(),
  passwordHash: text("password_hash").notNull(),
  role: roleEnum("role").notNull().default("USER"),
  lobId: integer("lob_id").references(() => lobs.id, { onDelete: "set null" }),
  // Reporting leader (self-referencing FK) -- resolved via relations below
  reportingLeaderId: integer("reporting_leader_id"),
  status: accountStatusEnum("status").notNull().default("ACTIVE"),
  phone: varchar("phone", { length: 40 }),
  designation: varchar("designation", { length: 120 }),
  joinDate: date("join_date"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  employeeIdUnique: uniqueIndex("users_employee_id_unique").on(t.employeeId),
  emailUnique: uniqueIndex("users_email_unique").on(t.email),
  lobIdx: index("users_lob_idx").on(t.lobId),
  leaderIdx: index("users_leader_idx").on(t.reportingLeaderId),
  roleIdx: index("users_role_idx").on(t.role),
}));

export const usersRelations = relations(users, ({ one, many }) => ({
  lob: one(lobs, { fields: [users.lobId], references: [lobs.id] }),
  leader: one(users, {
    fields: [users.reportingLeaderId],
    references: [users.id],
    relationName: "leader_subordinates",
  }),
  subordinates: many(users, { relationName: "leader_subordinates" }),
  assignments: many(rosterAssignments),
}));

/* ------------------------------------------------------------------ */
/*  SHIFTS (shift definitions/templates, e.g. "Morning 08:00-16:00")   */
/* ------------------------------------------------------------------ */

export const shifts = pgTable("shifts", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 120 }).notNull(),
  code: varchar("code", { length: 20 }).notNull(),
  startTime: time("start_time").notNull(),
  endTime: time("end_time").notNull(),
  colorHex: varchar("color_hex", { length: 12 }).default("#2563eb"),
  isOvernight: boolean("is_overnight").notNull().default(false),
  isActive: boolean("is_active").notNull().default(true),
  description: text("description"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  codeUnique: uniqueIndex("shifts_code_unique").on(t.code),
}));

/* ------------------------------------------------------------------ */
/*  ROSTER ASSIGNMENTS (a shift assigned to an employee on a date)     */
/* ------------------------------------------------------------------ */

export const rosterAssignments = pgTable("roster_assignments", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  shiftId: integer("shift_id").notNull().references(() => shifts.id, { onDelete: "restrict" }),
  date: date("date").notNull(),
  status: assignmentStatusEnum("status").notNull().default("SCHEDULED"),
  notes: text("notes"),
  assignedById: integer("assigned_by_id").references(() => users.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  // Prevent duplicate/conflicting assignment: one active roster row per user per date
  userDateUnique: uniqueIndex("roster_user_date_unique").on(t.userId, t.date),
  dateIdx: index("roster_date_idx").on(t.date),
  shiftIdx: index("roster_shift_idx").on(t.shiftId),
}));

export const rosterAssignmentsRelations = relations(rosterAssignments, ({ one }) => ({
  user: one(users, { fields: [rosterAssignments.userId], references: [users.id] }),
  shift: one(shifts, { fields: [rosterAssignments.shiftId], references: [shifts.id] }),
  assignedBy: one(users, { fields: [rosterAssignments.assignedById], references: [users.id] }),
}));

/* ------------------------------------------------------------------ */
/*  ROSTER CHANGE HISTORY (audit trail specific to roster edits)       */
/* ------------------------------------------------------------------ */

export const rosterHistory = pgTable("roster_history", {
  id: serial("id").primaryKey(),
  assignmentId: integer("assignment_id").references(() => rosterAssignments.id, { onDelete: "set null" }),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  date: date("date").notNull(),
  previousShiftId: integer("previous_shift_id").references(() => shifts.id),
  newShiftId: integer("new_shift_id").references(() => shifts.id),
  changeType: varchar("change_type", { length: 40 }).notNull(), // CREATED, UPDATED, CANCELLED, SWAPPED
  changedById: integer("changed_by_id").notNull().references(() => users.id),
  reason: text("reason"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  userIdx: index("roster_history_user_idx").on(t.userId),
  dateIdx: index("roster_history_date_idx").on(t.date),
}));

/* ------------------------------------------------------------------ */
/*  SHIFT SWAP REQUESTS                                                */
/* ------------------------------------------------------------------ */

export const shiftSwapRequests = pgTable("shift_swap_requests", {
  id: serial("id").primaryKey(),
  requesterId: integer("requester_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  requesterAssignmentId: integer("requester_assignment_id").notNull().references(() => rosterAssignments.id, { onDelete: "cascade" }),
  counterpartyId: integer("counterparty_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  counterpartyAssignmentId: integer("counterparty_assignment_id").notNull().references(() => rosterAssignments.id, { onDelete: "cascade" }),
  status: swapStatusEnum("status").notNull().default("PENDING_COUNTERPARTY"),
  reason: text("reason"),
  counterpartyRespondedAt: timestamp("counterparty_responded_at", { withTimezone: true }),
  counterpartyRespondedById: integer("counterparty_responded_by_id").references(() => users.id),
  leaderId: integer("leader_id").references(() => users.id, { onDelete: "set null" }),
  leaderRespondedAt: timestamp("leader_responded_at", { withTimezone: true }),
  leaderRespondedById: integer("leader_responded_by_id").references(() => users.id),
  leaderComment: text("leader_comment"),
  isAdminOverride: boolean("is_admin_override").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  requesterIdx: index("swap_requester_idx").on(t.requesterId),
  counterpartyIdx: index("swap_counterparty_idx").on(t.counterpartyId),
  statusIdx: index("swap_status_idx").on(t.status),
}));

export const shiftSwapRequestsRelations = relations(shiftSwapRequests, ({ one }) => ({
  requester: one(users, { fields: [shiftSwapRequests.requesterId], references: [users.id], relationName: "swap_requester" }),
  counterparty: one(users, { fields: [shiftSwapRequests.counterpartyId], references: [users.id], relationName: "swap_counterparty" }),
  leader: one(users, { fields: [shiftSwapRequests.leaderId], references: [users.id], relationName: "swap_leader" }),
  requesterAssignment: one(rosterAssignments, { fields: [shiftSwapRequests.requesterAssignmentId], references: [rosterAssignments.id], relationName: "swap_requester_assignment" }),
  counterpartyAssignment: one(rosterAssignments, { fields: [shiftSwapRequests.counterpartyAssignmentId], references: [rosterAssignments.id], relationName: "swap_counterparty_assignment" }),
}));

/* ------------------------------------------------------------------ */
/*  NOTIFICATIONS                                                      */
/* ------------------------------------------------------------------ */

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  type: notificationTypeEnum("type").notNull(),
  title: varchar("title", { length: 200 }).notNull(),
  message: text("message").notNull(),
  isRead: boolean("is_read").notNull().default(false),
  relatedSwapId: integer("related_swap_id").references(() => shiftSwapRequests.id, { onDelete: "cascade" }),
  relatedAssignmentId: integer("related_assignment_id").references(() => rosterAssignments.id, { onDelete: "cascade" }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  userIdx: index("notifications_user_idx").on(t.userId),
  readIdx: index("notifications_read_idx").on(t.isRead),
}));

/* ------------------------------------------------------------------ */
/*  AUDIT / ACTIVITY LOG (system-wide)                                 */
/* ------------------------------------------------------------------ */

export const auditLogs = pgTable("audit_logs", {
  id: serial("id").primaryKey(),
  actorId: integer("actor_id").references(() => users.id, { onDelete: "set null" }),
  action: varchar("action", { length: 80 }).notNull(), // e.g. USER_CREATED, SHIFT_ASSIGNED
  entityType: varchar("entity_type", { length: 40 }).notNull(), // USER, SHIFT, ROSTER, SWAP, SYSTEM
  entityId: integer("entity_id"),
  previousValue: jsonb("previous_value"),
  newValue: jsonb("new_value"),
  description: text("description"),
  ipAddress: varchar("ip_address", { length: 64 }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  actorIdx: index("audit_actor_idx").on(t.actorId),
  entityIdx: index("audit_entity_idx").on(t.entityType, t.entityId),
  createdIdx: index("audit_created_idx").on(t.createdAt),
}));

/* ------------------------------------------------------------------ */
/*  SYSTEM SETTINGS (key/value config store)                           */
/* ------------------------------------------------------------------ */

export const systemSettings = pgTable("system_settings", {
  id: serial("id").primaryKey(),
  key: varchar("key", { length: 120 }).notNull(),
  value: jsonb("value").notNull(),
  description: text("description"),
  updatedById: integer("updated_by_id").references(() => users.id),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  keyUnique: uniqueIndex("system_settings_key_unique").on(t.key),
}));
