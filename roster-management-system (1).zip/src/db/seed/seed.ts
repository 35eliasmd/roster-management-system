/**
 * Seed script — populates the database with sample LOBs, shifts, and users
 * (one Admin, two Leaders, several Users) plus a few days of roster data.
 *
 * Run with:  npm run db:seed
 */
import "dotenv/config";
import { drizzle } from "drizzle-orm/neon-http";
import { neon } from "@neondatabase/serverless";
import bcrypt from "bcryptjs";
import * as schema from "../schema";

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL is not set. Add it to .env.local before seeding.");
}

const sql = neon(process.env.DATABASE_URL);
const db = drizzle(sql, { schema });

async function main() {
  console.log("Seeding database...");

  const passwordHash = await bcrypt.hash("Password123!", 10);

  // --- LOBs ---
  const [lobOps] = await db.insert(schema.lobs).values({ name: "Operations", code: "OPS" }).returning();
  const [lobSupport] = await db.insert(schema.lobs).values({ name: "Customer Support", code: "SUP" }).returning();

  // --- Shifts ---
  const [morning] = await db.insert(schema.shifts).values({
    name: "Morning", code: "MOR", startTime: "08:00", endTime: "16:00", colorHex: "#2563eb",
  }).returning();
  const [evening] = await db.insert(schema.shifts).values({
    name: "Evening", code: "EVE", startTime: "16:00", endTime: "00:00", colorHex: "#7c3aed",
  }).returning();
  const [night] = await db.insert(schema.shifts).values({
    name: "Night", code: "NGT", startTime: "00:00", endTime: "08:00", colorHex: "#0f172a", isOvernight: true,
  }).returning();

  // --- Admin ---
  const [admin] = await db.insert(schema.users).values({
    employeeId: "ADM001",
    name: "System Administrator",
    email: "admin@roster.local",
    passwordHash,
    role: "ADMIN",
    status: "ACTIVE",
    designation: "System Administrator",
  }).returning();

  // --- Leaders ---
  const [leaderOps] = await db.insert(schema.users).values({
    employeeId: "LDR001",
    name: "Alice Leader",
    email: "alice.leader@roster.local",
    passwordHash,
    role: "LEADER",
    lobId: lobOps.id,
    status: "ACTIVE",
    designation: "Operations Team Lead",
  }).returning();

  const [leaderSupport] = await db.insert(schema.users).values({
    employeeId: "LDR002",
    name: "Bob Leader",
    email: "bob.leader@roster.local",
    passwordHash,
    role: "LEADER",
    lobId: lobSupport.id,
    status: "ACTIVE",
    designation: "Support Team Lead",
  }).returning();

  // --- Users ---
  const userSeeds = [
    { employeeId: "EMP001", name: "Charlie User", email: "charlie@roster.local", lobId: lobOps.id, leaderId: leaderOps.id },
    { employeeId: "EMP002", name: "Dana User", email: "dana@roster.local", lobId: lobOps.id, leaderId: leaderOps.id },
    { employeeId: "EMP003", name: "Evan User", email: "evan@roster.local", lobId: lobSupport.id, leaderId: leaderSupport.id },
    { employeeId: "EMP004", name: "Fiona User", email: "fiona@roster.local", lobId: lobSupport.id, leaderId: leaderSupport.id },
  ];

  const createdUsers = [];
  for (const u of userSeeds) {
    const [created] = await db.insert(schema.users).values({
      employeeId: u.employeeId,
      name: u.name,
      email: u.email,
      passwordHash,
      role: "USER",
      lobId: u.lobId,
      reportingLeaderId: u.leaderId,
      status: "ACTIVE",
      designation: "Associate",
    }).returning();
    createdUsers.push(created);
  }

  // --- Roster: assign shifts for today and the next 3 days ---
  const shiftCycle = [morning, evening, night];
  const today = new Date();
  for (let dayOffset = 0; dayOffset < 4; dayOffset++) {
    const date = new Date(today);
    date.setDate(today.getDate() + dayOffset);
    const dateStr = date.toISOString().slice(0, 10);

    for (let i = 0; i < createdUsers.length; i++) {
      const shift = shiftCycle[(i + dayOffset) % shiftCycle.length];
      await db.insert(schema.rosterAssignments).values({
        userId: createdUsers[i].id,
        shiftId: shift.id,
        date: dateStr,
        assignedById: admin.id,
      });
    }
  }

  console.log("Seed complete.");
  console.log("---------------------------------------------");
  console.log("Login credentials (all use password: Password123!)");
  console.log("  Admin:   admin@roster.local");
  console.log("  Leader:  alice.leader@roster.local (Operations)");
  console.log("  Leader:  bob.leader@roster.local (Support)");
  console.log("  User:    charlie@roster.local (Operations, reports to Alice)");
  console.log("  User:    dana@roster.local (Operations, reports to Alice)");
  console.log("  User:    evan@roster.local (Support, reports to Bob)");
  console.log("  User:    fiona@roster.local (Support, reports to Bob)");
  console.log("---------------------------------------------");
}

main()
  .then(() => process.exit(0))
  .catch((err) => {
    console.error("Seed failed:", err);
    process.exit(1);
  });
