"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { createLob } from "@/lib/actions/lobs";

interface Lob {
  id: number;
  name: string;
  code: string;
  description: string | null;
  isActive: boolean;
}

export function LobManager({ lobs }: { lobs: Lob[] }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: "", code: "", description: "" });
  const [error, setError] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();

  function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    startTransition(async () => {
      try {
        await createLob(form);
        setOpen(false);
        setForm({ name: "", code: "", description: "" });
        router.refresh();
      } catch (err) {
        setError(err instanceof Error ? err.message : "Failed to create LOB.");
      }
    });
  }

  return (
    <>
      {!open ? (
        <button className="btn-primary mb-6" onClick={() => setOpen(true)}>+ New LOB / Team</button>
      ) : (
        <form onSubmit={submit} className="card p-5 mb-6 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium mb-1" style={{ color: "var(--ink-soft)" }}>Name</label>
              <input required className="input w-full" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1" style={{ color: "var(--ink-soft)" }}>Code</label>
              <input required className="input w-full" value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value.toUpperCase() })} />
            </div>
            <div className="col-span-2">
              <label className="block text-xs font-medium mb-1" style={{ color: "var(--ink-soft)" }}>Description</label>
              <input className="input w-full" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
            </div>
          </div>
          {error && <p className="text-sm" style={{ color: "var(--rust)" }}>{error}</p>}
          <div className="flex gap-3">
            <button type="submit" disabled={isPending} className="btn-primary">{isPending ? "Saving..." : "Save"}</button>
            <button type="button" className="btn-secondary" onClick={() => setOpen(false)}>Cancel</button>
          </div>
        </form>
      )}

      <div className="card overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b" style={{ borderColor: "var(--line)" }}>
              {["Name", "Code", "Description", "Status"].map((h) => (
                <th key={h} className="text-left px-4 py-3 font-medium" style={{ color: "var(--ink-soft)" }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {lobs.map((l) => (
              <tr key={l.id} className="border-b last:border-0" style={{ borderColor: "var(--line)" }}>
                <td className="px-4 py-3 font-medium">{l.name}</td>
                <td className="px-4 py-3">{l.code}</td>
                <td className="px-4 py-3" style={{ color: "var(--ink-soft)" }}>{l.description || "—"}</td>
                <td className="px-4 py-3">
                  <span className="badge" style={{ background: "var(--teal-soft)", color: "var(--teal)" }}>
                    {l.isActive ? "Active" : "Inactive"}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
