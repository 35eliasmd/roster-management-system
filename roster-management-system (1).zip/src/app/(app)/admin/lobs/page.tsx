import { auth } from "@/auth";
import { redirect } from "next/navigation";
import { listLobs } from "@/lib/actions/lobs";
import { LobManager } from "./lob-manager";

export default async function AdminLobsPage() {
  const session = await auth();
  if (session?.user.role !== "ADMIN") redirect("/dashboard?error=forbidden");

  const lobs = await listLobs();

  return (
    <div className="max-w-2xl">
      <header className="mb-6">
        <h1 className="text-2xl font-semibold">LOB / Teams</h1>
        <p className="text-sm mt-1" style={{ color: "var(--ink-soft)" }}>
          Define the lines of business / teams employees belong to.
        </p>
      </header>
      <LobManager lobs={lobs} />
    </div>
  );
}
