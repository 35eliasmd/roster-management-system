import { auth } from "@/auth";
import { redirect } from "next/navigation";
import { listAuditLogs } from "@/lib/actions/notifications";

export default async function AuditLogsPage() {
  const session = await auth();
  if (session?.user.role !== "ADMIN") redirect("/dashboard?error=forbidden");

  const logs = await listAuditLogs(150);

  return (
    <div className="max-w-5xl">
      <header className="mb-6">
        <h1 className="text-2xl font-semibold">Audit / Activity Log</h1>
        <p className="text-sm mt-1" style={{ color: "var(--ink-soft)" }}>
          A complete, tamper-evident record of who changed what, and when.
        </p>
      </header>

      <div className="card overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b" style={{ borderColor: "var(--line)" }}>
              {["Time", "Actor", "Action", "Entity", "Description"].map((h) => (
                <th key={h} className="text-left px-4 py-3 font-medium" style={{ color: "var(--ink-soft)" }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {logs.map((l) => (
              <tr key={l.id} className="border-b last:border-0 align-top" style={{ borderColor: "var(--line)" }}>
                <td className="px-4 py-3 whitespace-nowrap text-xs" style={{ color: "var(--ink-soft)" }}>
                  {new Date(l.createdAt).toLocaleString()}
                </td>
                <td className="px-4 py-3">
                  {l.actorName ? (
                    <>
                      {l.actorName} <span className="text-xs" style={{ color: "var(--ink-soft)" }}>#{l.actorEmployeeId}</span>
                    </>
                  ) : (
                    <span style={{ color: "var(--ink-soft)" }}>System</span>
                  )}
                </td>
                <td className="px-4 py-3">
                  <span className="badge" style={{ background: "var(--teal-soft)", color: "var(--teal)" }}>{l.action}</span>
                </td>
                <td className="px-4 py-3 text-xs" style={{ color: "var(--ink-soft)" }}>
                  {l.entityType}{l.entityId ? ` #${l.entityId}` : ""}
                </td>
                <td className="px-4 py-3 text-xs max-w-xs" style={{ color: "var(--ink-soft)" }}>
                  {l.description || "—"}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {logs.length === 0 && (
          <p className="p-8 text-center text-sm" style={{ color: "var(--ink-soft)" }}>No activity recorded yet.</p>
        )}
      </div>
    </div>
  );
}
