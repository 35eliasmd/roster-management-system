import { auth } from "@/auth";
import { redirect } from "next/navigation";
import { listShifts } from "@/lib/actions/shifts";
import { ShiftCatalog } from "./shift-catalog";

export default async function AdminShiftsPage() {
  const session = await auth();
  if (session?.user.role !== "ADMIN") redirect("/dashboard?error=forbidden");

  const shifts = await listShifts();

  return (
    <div className="max-w-3xl">
      <header className="mb-6">
        <h1 className="text-2xl font-semibold">Shift Catalog</h1>
        <p className="text-sm mt-1" style={{ color: "var(--ink-soft)" }}>
          Define the shift templates available for roster assignment.
        </p>
      </header>
      <ShiftCatalog shifts={shifts} />
    </div>
  );
}
