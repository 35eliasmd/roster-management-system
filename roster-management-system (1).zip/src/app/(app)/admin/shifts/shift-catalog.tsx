"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { createShift, updateShift, deleteShift } from "@/lib/actions/shifts";

interface Shift {
  id: number;
  name: string;
  code: string;
  startTime: string;
  endTime: string;
  colorHex: string | null;
  isOvernight: boolean;
  isActive: boolean;
}

export function ShiftCatalog({ shifts }: { shifts: Shift[] }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [isPending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);
  const [form, setForm] = useState({ name: "", code: "", startTime: "08:00", endTime: "16:00", colorHex: "#1e3a4c" });

  function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    startTransition(async () => {
      try {
        await createShift(form);
        setOpen(false);
        setForm({ name: "", code: "", startTime: "08:00", endTime: "16:00", colorHex: "#1e3a4c" });
        router.refresh();
      } catch (err) {
        setError(err instanceof Error ? err.message : "Failed to create shift.");
      }
    });
  }

  function toggleActive(id: number, isActive: boolean) {
    startTransition(async () => {
      if (isActive) await deleteShift(id);
      else await updateShift({ id, isActive: true });
      router.refresh();
    });
  }

  return (
    <>
      {!open ? (
        <button className="btn-primary mb-6" onClick={() => setOpen(true)}>
          + New shift
        </button>
      ) : (
        <form onSubmit={submit} className="card p-5 mb-6 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium mb-1" style={{ color: "var(--ink-soft)" }}>Name</label>
              <input required className="input w-full" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1" style={{ color: "var(--ink-soft)" }}>Code</label>
              <input required className="input w-full" value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value.toUpperCase() })} />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1" style={{ color: "var(--ink-soft)" }}>Start time</label>
              <input required type="time" className="input w-full" value={form.startTime} onChange={(e) => setForm({ ...form, startTime: e.target.value })} />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1" style={{ color: "var(--ink-soft)" }}>End time</label>
              <input required type="time" className="input w-full" value={form.endTime} onChange={(e) => setForm({ ...form, endTime: e.target.value })} />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1" style={{ color: "var(--ink-soft)" }}>Color</label>
              <input type="color" className="input w-full h-9" value={form.colorHex} onChange={(e) => setForm({ ...form, colorHex: e.target.value })} />
            </div>
          </div>
          {error && <p className="text-sm" style={{ color: "var(--rust)" }}>{error}</p>}
          <div className="flex gap-3">
            <button type="submit" disabled={isPending} className="btn-primary">{isPending ? "Saving..." : "Save shift"}</button>
            <button type="button" className="btn-secondary" onClick={() => setOpen(false)}>Cancel</button>
          </div>
        </form>
      )}

      <div className="card overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b" style={{ borderColor: "var(--line)" }}>
              {["Name", "Code", "Time", "Status", "Actions"].map((h) => (
                <th key={h} className="text-left px-4 py-3 font-medium" style={{ color: "var(--ink-soft)" }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {shifts.map((s) => (
              <tr key={s.id} className="border-b last:border-0" style={{ borderColor: "var(--line)" }}>
                <td className="px-4 py-3">
                  <span className="inline-block w-2.5 h-2.5 rounded-full mr-2" style={{ background: s.colorHex || "#1e3a4c" }} />
                  {s.name}
                </td>
                <td className="px-4 py-3">{s.code}</td>
                <td className="px-4 py-3" style={{ color: "var(--ink-soft)" }}>{s.startTime}–{s.endTime}</td>
                <td className="px-4 py-3">
                  <span className="badge" style={s.isActive ? { background: "var(--teal-soft)", color: "var(--teal)" } : { background: "#eee", color: "#666" }}>
                    {s.isActive ? "Active" : "Inactive"}
                  </span>
                </td>
                <td className="px-4 py-3">
                  <button disabled={isPending} className="text-xs font-medium" style={{ color: s.isActive ? "var(--rust)" : "var(--teal)" }} onClick={() => toggleActive(s.id, s.isActive)}>
                    {s.isActive ? "Deactivate" : "Activate"}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
