"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { createUser } from "@/lib/actions/users";

export function NewUserForm({
  lobs,
  leaders,
}: {
  lobs: { id: number; name: string }[];
  leaders: { id: number; name: string }[];
}) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    employeeId: "",
    name: "",
    email: "",
    password: "",
    role: "USER" as "ADMIN" | "LEADER" | "USER",
    lobId: "",
    reportingLeaderId: "",
    designation: "",
  });
  const [error, setError] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();

  function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    startTransition(async () => {
      try {
        await createUser({
          employeeId: form.employeeId,
          name: form.name,
          email: form.email,
          password: form.password,
          role: form.role,
          lobId: form.lobId ? Number(form.lobId) : undefined,
          reportingLeaderId: form.reportingLeaderId ? Number(form.reportingLeaderId) : undefined,
          designation: form.designation || undefined,
        });
        setOpen(false);
        setForm({ employeeId: "", name: "", email: "", password: "", role: "USER", lobId: "", reportingLeaderId: "", designation: "" });
        router.refresh();
      } catch (err) {
        setError(err instanceof Error ? err.message : "Failed to create user.");
      }
    });
  }

  if (!open) {
    return (
      <button className="btn-primary mb-6" onClick={() => setOpen(true)}>
        + New user
      </button>
    );
  }

  return (
    <form onSubmit={submit} className="card p-5 mb-6 space-y-4">
      <h2 className="font-semibold text-sm">Create user</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Field label="Employee ID">
          <input required className="input w-full" value={form.employeeId} onChange={(e) => setForm({ ...form, employeeId: e.target.value })} />
        </Field>
        <Field label="Full name">
          <input required className="input w-full" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
        </Field>
        <Field label="Email">
          <input required type="email" className="input w-full" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
        </Field>
        <Field label="Temporary password">
          <input required type="text" minLength={6} className="input w-full" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
        </Field>
        <Field label="Role">
          <select className="input w-full" value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value as "ADMIN" | "LEADER" | "USER" })}>
            <option value="USER">User</option>
            <option value="LEADER">Leader</option>
            <option value="ADMIN">Administrator</option>
          </select>
        </Field>
        <Field label="LOB / Team">
          <select className="input w-full" value={form.lobId} onChange={(e) => setForm({ ...form, lobId: e.target.value })}>
            <option value="">None</option>
            {lobs.map((l) => (
              <option key={l.id} value={l.id}>{l.name}</option>
            ))}
          </select>
        </Field>
        <Field label="Reporting leader">
          <select className="input w-full" value={form.reportingLeaderId} onChange={(e) => setForm({ ...form, reportingLeaderId: e.target.value })}>
            <option value="">None</option>
            {leaders.map((l) => (
              <option key={l.id} value={l.id}>{l.name}</option>
            ))}
          </select>
        </Field>
        <Field label="Designation">
          <input className="input w-full" value={form.designation} onChange={(e) => setForm({ ...form, designation: e.target.value })} />
        </Field>
      </div>

      {error && <p className="text-sm" style={{ color: "var(--rust)" }}>{error}</p>}

      <div className="flex gap-3">
        <button type="submit" disabled={isPending} className="btn-primary">
          {isPending ? "Creating..." : "Create user"}
        </button>
        <button type="button" className="btn-secondary" onClick={() => setOpen(false)}>
          Cancel
        </button>
      </div>
    </form>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-xs font-medium mb-1" style={{ color: "var(--ink-soft)" }}>
        {label}
      </label>
      {children}
    </div>
  );
}
