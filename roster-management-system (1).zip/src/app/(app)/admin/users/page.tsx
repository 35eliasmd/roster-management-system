import { db } from "@/db";
import { users, lobs } from "@/db/schema";
import { eq } from "drizzle-orm";
import { auth } from "@/auth";
import { redirect } from "next/navigation";
import { UserTable } from "./user-table";
import { NewUserForm } from "./new-user-form";
import { alias } from "drizzle-orm/pg-core";

export default async function AdminUsersPage() {
  const session = await auth();
  if (session?.user.role !== "ADMIN") redirect("/dashboard?error=forbidden");

  const leaderAlias = alias(users, "leader");

  const rows = await db
    .select({
      id: users.id,
      employeeId: users.employeeId,
      name: users.name,
      email: users.email,
      role: users.role,
      status: users.status,
      lobName: lobs.name,
      leaderName: leaderAlias.name,
    })
    .from(users)
    .leftJoin(lobs, eq(users.lobId, lobs.id))
    .leftJoin(leaderAlias, eq(users.reportingLeaderId, leaderAlias.id));

  const allLobs = await db.select().from(lobs);
  const allLeaders = await db.select().from(users).where(eq(users.role, "LEADER"));

  return (
    <div className="max-w-5xl">
      <header className="mb-6">
        <h1 className="text-2xl font-semibold">Users</h1>
        <p className="text-sm mt-1" style={{ color: "var(--ink-soft)" }}>
          Create and manage all employees, leaders, and administrators.
        </p>
      </header>

      <NewUserForm
        lobs={allLobs.map((l) => ({ id: l.id, name: l.name }))}
        leaders={allLeaders.map((l) => ({ id: l.id, name: l.name }))}
      />
      <UserTable
        rows={rows}
        lobs={allLobs.map((l) => ({ id: l.id, name: l.name }))}
        leaders={allLeaders.map((l) => ({ id: l.id, name: l.name }))}
      />
    </div>
  );
}
