"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { updateUser, deleteUser } from "@/lib/actions/users";

interface Row {
  id: number;
  employeeId: string;
  name: string;
  email: string;
  role: string;
  status: string;
  lobName: string | null;
  leaderName: string | null;
}

export function UserTable({
  rows,
  lobs,
  leaders,
}: {
  rows: Row[];
  lobs: { id: number; name: string }[];
  leaders: { id: number; name: string }[];
}) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);

  function changeStatus(id: number, status: "ACTIVE" | "INACTIVE" | "SUSPENDED") {
    setError(null);
    startTransition(async () => {
      try {
        await updateUser({ id, status });
        router.refresh();
      } catch (e) {
        setError(e instanceof Error ? e.message : "Update failed.");
      }
    });
  }

  function remove(id: number) {
    if (!confirm("Deactivate this user? Their history will be preserved.")) return;
    setError(null);
    startTransition(async () => {
      try {
        await deleteUser(id);
        router.refresh();
      } catch (e) {
        setError(e instanceof Error ? e.message : "Delete failed.");
      }
    });
  }

  return (
    <div className="card overflow-hidden">
      {error && (
        <p className="px-4 py-2 text-sm" style={{ background: "var(--rust-soft)", color: "var(--rust)" }}>
          {error}
        </p>
      )}
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b" style={{ borderColor: "var(--line)" }}>
            {["Employee", "Email", "Role", "LOB", "Reports to", "Status", "Actions"].map((h) => (
              <th key={h} className="text-left px-4 py-3 font-medium" style={{ color: "var(--ink-soft)" }}>
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.id} className="border-b last:border-0" style={{ borderColor: "var(--line)" }}>
              <td className="px-4 py-3">
                <span className="font-medium">{r.name}</span>{" "}
                <span className="text-xs" style={{ color: "var(--ink-soft)" }}>#{r.employeeId}</span>
              </td>
              <td className="px-4 py-3">{r.email}</td>
              <td className="px-4 py-3">
                <span className="badge" style={{ background: "var(--teal-soft)", color: "var(--teal)" }}>{r.role}</span>
              </td>
              <td className="px-4 py-3">{r.lobName || "—"}</td>
              <td className="px-4 py-3">{r.leaderName || "—"}</td>
              <td className="px-4 py-3">
                <span
                  className="badge"
                  style={
                    r.status === "ACTIVE"
                      ? { background: "var(--teal-soft)", color: "var(--teal)" }
                      : { background: "var(--rust-soft)", color: "var(--rust)" }
                  }
                >
                  {r.status}
                </span>
              </td>
              <td className="px-4 py-3 whitespace-nowrap">
                {r.status === "ACTIVE" ? (
                  <button disabled={isPending} className="text-xs font-medium mr-3" style={{ color: "var(--rust)" }} onClick={() => remove(r.id)}>
                    Deactivate
                  </button>
                ) : (
                  <button disabled={isPending} className="text-xs font-medium mr-3" style={{ color: "var(--teal)" }} onClick={() => changeStatus(r.id, "ACTIVE")}>
                    Reactivate
                  </button>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
