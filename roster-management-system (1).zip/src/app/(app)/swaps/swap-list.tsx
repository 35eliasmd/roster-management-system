"use client";

import { useTransition, useState } from "react";
import { useRouter } from "next/navigation";
import {
  respondToSwapAsCounterparty,
  decideSwapAsLeader,
  cancelSwapRequest,
} from "@/lib/actions/swaps";
import type { Role } from "@/lib/permissions";

interface SwapRow {
  id: number;
  status: string;
  reason: string | null;
  createdAt: Date;
  leaderComment: string | null;
  requesterId: number;
  requesterName: string;
  requesterDate: string;
  requesterShiftName: string;
  counterpartyId: number;
  counterpartyName: string;
  counterpartyDate: string;
  counterpartyShiftName: string;
  leaderId: number | null;
}

const STATUS_LABEL: Record<string, string> = {
  PENDING_COUNTERPARTY: "Awaiting employee confirmation",
  PENDING_LEADER: "Awaiting leader approval",
  APPROVED: "Approved — roster updated",
  REJECTED_BY_COUNTERPARTY: "Rejected by employee",
  REJECTED_BY_LEADER: "Rejected by leader",
  CANCELLED: "Cancelled",
};

const STATUS_STYLE: Record<string, { bg: string; fg: string }> = {
  PENDING_COUNTERPARTY: { bg: "var(--amber-soft)", fg: "var(--amber)" },
  PENDING_LEADER: { bg: "var(--amber-soft)", fg: "var(--amber)" },
  APPROVED: { bg: "var(--teal-soft)", fg: "var(--teal)" },
  REJECTED_BY_COUNTERPARTY: { bg: "var(--rust-soft)", fg: "var(--rust)" },
  REJECTED_BY_LEADER: { bg: "var(--rust-soft)", fg: "var(--rust)" },
  CANCELLED: { bg: "#eee", fg: "#666" },
};

export function SwapList({
  rows,
  currentUserId,
  currentUserRole,
}: {
  rows: SwapRow[];
  currentUserId: number;
  currentUserRole: Role;
}) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);

  function act(fn: () => Promise<unknown>) {
    setError(null);
    startTransition(async () => {
      try {
        await fn();
        router.refresh();
      } catch (e) {
        setError(e instanceof Error ? e.message : "Action failed.");
      }
    });
  }

  const sorted = [...rows].sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt));

  if (sorted.length === 0) {
    return (
      <div className="card p-10 text-center">
        <p className="text-sm" style={{ color: "var(--ink-soft)" }}>
          No shift swap requests yet.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {error && (
        <p className="text-sm px-3 py-2 rounded-lg" style={{ background: "var(--rust-soft)", color: "var(--rust)" }}>
          {error}
        </p>
      )}
      {sorted.map((s) => {
        const style = STATUS_STYLE[s.status] ?? { bg: "#eee", fg: "#666" };
        const isCounterparty = s.counterpartyId === currentUserId && s.status === "PENDING_COUNTERPARTY";
        const isApprovingLeader =
          s.status === "PENDING_LEADER" &&
          (currentUserRole === "ADMIN" || (currentUserRole === "LEADER" && s.leaderId === currentUserId));
        const isRequester = s.requesterId === currentUserId;
        const canCancel =
          (isRequester || currentUserRole === "ADMIN") &&
          (s.status === "PENDING_COUNTERPARTY" || s.status === "PENDING_LEADER");

        return (
          <div key={s.id} className="card p-4">
            <div className="flex items-start justify-between gap-4 flex-wrap">
              <div>
                <p className="text-sm font-medium">
                  {s.requesterName}{" "}
                  <span style={{ color: "var(--ink-soft)" }}>
                    ({s.requesterDate} · {s.requesterShiftName})
                  </span>{" "}
                  ⇄{" "}
                  {s.counterpartyName}{" "}
                  <span style={{ color: "var(--ink-soft)" }}>
                    ({s.counterpartyDate} · {s.counterpartyShiftName})
                  </span>
                </p>
                {s.reason && (
                  <p className="text-xs mt-1" style={{ color: "var(--ink-soft)" }}>
                    Reason: {s.reason}
                  </p>
                )}
                {s.leaderComment && (
                  <p className="text-xs mt-1" style={{ color: "var(--ink-soft)" }}>
                    Leader note: {s.leaderComment}
                  </p>
                )}
              </div>
              <span className="badge shrink-0" style={{ background: style.bg, color: style.fg }}>
                {STATUS_LABEL[s.status] ?? s.status}
              </span>
            </div>

            {(isCounterparty || isApprovingLeader || canCancel) && (
              <div className="flex gap-2 mt-3">
                {isCounterparty && (
                  <>
                    <button
                      disabled={isPending}
                      className="btn-primary"
                      onClick={() => act(() => respondToSwapAsCounterparty({ swapId: s.id, accept: true }))}
                    >
                      Accept
                    </button>
                    <button
                      disabled={isPending}
                      className="btn-danger"
                      onClick={() => act(() => respondToSwapAsCounterparty({ swapId: s.id, accept: false }))}
                    >
                      Reject
                    </button>
                  </>
                )}
                {isApprovingLeader && (
                  <>
                    <button
                      disabled={isPending}
                      className="btn-primary"
                      onClick={() => act(() => decideSwapAsLeader({ swapId: s.id, approve: true }))}
                    >
                      Approve swap
                    </button>
                    <button
                      disabled={isPending}
                      className="btn-danger"
                      onClick={() => act(() => decideSwapAsLeader({ swapId: s.id, approve: false }))}
                    >
                      Reject
                    </button>
                  </>
                )}
                {canCancel && !isCounterparty && !isApprovingLeader && (
                  <button
                    disabled={isPending}
                    className="btn-secondary"
                    onClick={() => act(() => cancelSwapRequest(s.id))}
                  >
                    Cancel request
                  </button>
                )}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
