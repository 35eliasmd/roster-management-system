"use client";

import { useEffect, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { createSwapRequest } from "@/lib/actions/swaps";
import { getUserScheduledAssignments } from "@/lib/actions/roster";

interface MyAssignment {
  id: number;
  date: string;
  shiftName: string;
}
interface Employee {
  id: number;
  name: string;
  employeeId: string;
}

export function NewSwapRequestForm({
  myAssignments,
  employees,
}: {
  myAssignments: MyAssignment[];
  employees: Employee[];
}) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [myAssignmentId, setMyAssignmentId] = useState("");
  const [counterpartyId, setCounterpartyId] = useState("");
  const [counterpartyAssignmentId, setCounterpartyAssignmentId] = useState("");
  const [counterpartyAssignments, setCounterpartyAssignments] = useState<MyAssignment[]>([]);
  const [reason, setReason] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();

  useEffect(() => {
    if (!counterpartyId) return;
    let cancelled = false;
    getUserScheduledAssignments(Number(counterpartyId)).then((data) => {
      if (!cancelled) setCounterpartyAssignments(data);
    });
    return () => {
      cancelled = true;
    };
  }, [counterpartyId]);

  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!myAssignmentId || !counterpartyId || !counterpartyAssignmentId) return;
    setError(null);
    startTransition(async () => {
      try {
        await createSwapRequest({
          requesterAssignmentId: Number(myAssignmentId),
          counterpartyId: Number(counterpartyId),
          counterpartyAssignmentId: Number(counterpartyAssignmentId),
          reason: reason || undefined,
        });
        setOpen(false);
        setMyAssignmentId("");
        setCounterpartyId("");
        setCounterpartyAssignmentId("");
        setReason("");
        router.refresh();
      } catch (err) {
        setError(err instanceof Error ? err.message : "Failed to create swap request.");
      }
    });
  }

  if (!open) {
    return (
      <button className="btn-primary mb-6" onClick={() => setOpen(true)}>
        + Request a shift swap
      </button>
    );
  }

  return (
    <form onSubmit={submit} className="card p-5 mb-6 space-y-4">
      <h2 className="font-semibold text-sm">New swap request</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-xs font-medium mb-1" style={{ color: "var(--ink-soft)" }}>
            Your shift to offer
          </label>
          <select required value={myAssignmentId} onChange={(e) => setMyAssignmentId(e.target.value)} className="input w-full">
            <option value="">Select your shift</option>
            {myAssignments.map((a) => (
              <option key={a.id} value={a.id}>
                {a.date} — {a.shiftName}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-xs font-medium mb-1" style={{ color: "var(--ink-soft)" }}>
            Employee to swap with
          </label>
          <select
            required
            value={counterpartyId}
            onChange={(e) => {
              setCounterpartyId(e.target.value);
              setCounterpartyAssignmentId("");
              setCounterpartyAssignments([]);
            }}
            className="input w-full"
          >
            <option value="">Select employee</option>
            {employees.map((e) => (
              <option key={e.id} value={e.id}>
                {e.name} (#{e.employeeId})
              </option>
            ))}
          </select>
        </div>

        <div className="md:col-span-2">
          <label className="block text-xs font-medium mb-1" style={{ color: "var(--ink-soft)" }}>
            Their shift you want
          </label>
          <select
            required
            value={counterpartyAssignmentId}
            onChange={(e) => setCounterpartyAssignmentId(e.target.value)}
            className="input w-full"
            disabled={!counterpartyId}
          >
            <option value="">
              {counterpartyId ? "Select their shift" : "Choose an employee first"}
            </option>
            {counterpartyAssignments.map((a) => (
              <option key={a.id} value={a.id}>
                {a.date} — {a.shiftName}
              </option>
            ))}
          </select>
        </div>

        <div className="md:col-span-2">
          <label className="block text-xs font-medium mb-1" style={{ color: "var(--ink-soft)" }}>
            Reason (optional)
          </label>
          <input value={reason} onChange={(e) => setReason(e.target.value)} className="input w-full" placeholder="e.g. Personal appointment" />
        </div>
      </div>

      {error && <p className="text-sm" style={{ color: "var(--rust)" }}>{error}</p>}

      <div className="flex gap-3">
        <button type="submit" disabled={isPending} className="btn-primary">
          {isPending ? "Submitting..." : "Submit request"}
        </button>
        <button type="button" className="btn-secondary" onClick={() => setOpen(false)}>
          Cancel
        </button>
      </div>
    </form>
  );
}
