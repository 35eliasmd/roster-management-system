import { db } from "@/db";
import { shiftSwapRequests, users, rosterAssignments, shifts } from "@/db/schema";
import { eq, or, and, gte } from "drizzle-orm";
import { auth } from "@/auth";
import { alias } from "drizzle-orm/pg-core";
import { NewSwapRequestForm } from "./new-swap-request-form";
import { SwapList } from "./swap-list";
import { listVisibleUsers } from "@/lib/actions/users";
import { isAdmin, isLeader } from "@/lib/permissions";

export default async function SwapsPage() {
  const session = await auth();
  const user = session!.user;

  const requesterUser = alias(users, "requester_user");
  const counterpartyUser = alias(users, "counterparty_user");
  const requesterAssignment = alias(rosterAssignments, "requester_assignment");
  const counterpartyAssignment = alias(rosterAssignments, "counterparty_assignment");
  const requesterShift = alias(shifts, "requester_shift");
  const counterpartyShift = alias(shifts, "counterparty_shift");

  const baseQuery = db
    .select({
      id: shiftSwapRequests.id,
      status: shiftSwapRequests.status,
      reason: shiftSwapRequests.reason,
      createdAt: shiftSwapRequests.createdAt,
      leaderComment: shiftSwapRequests.leaderComment,
      requesterId: shiftSwapRequests.requesterId,
      requesterName: requesterUser.name,
      requesterDate: requesterAssignment.date,
      requesterShiftName: requesterShift.name,
      counterpartyId: shiftSwapRequests.counterpartyId,
      counterpartyName: counterpartyUser.name,
      counterpartyDate: counterpartyAssignment.date,
      counterpartyShiftName: counterpartyShift.name,
      leaderId: shiftSwapRequests.leaderId,
    })
    .from(shiftSwapRequests)
    .innerJoin(requesterUser, eq(shiftSwapRequests.requesterId, requesterUser.id))
    .innerJoin(counterpartyUser, eq(shiftSwapRequests.counterpartyId, counterpartyUser.id))
    .innerJoin(requesterAssignment, eq(shiftSwapRequests.requesterAssignmentId, requesterAssignment.id))
    .innerJoin(counterpartyAssignment, eq(shiftSwapRequests.counterpartyAssignmentId, counterpartyAssignment.id))
    .innerJoin(requesterShift, eq(requesterAssignment.shiftId, requesterShift.id))
    .innerJoin(counterpartyShift, eq(counterpartyAssignment.shiftId, counterpartyShift.id));

  let rows;
  if (isAdmin(user)) {
    rows = await baseQuery;
  } else if (isLeader(user)) {
    rows = await baseQuery.where(
      or(eq(shiftSwapRequests.leaderId, user.id), eq(shiftSwapRequests.requesterId, user.id), eq(shiftSwapRequests.counterpartyId, user.id))
    );
  } else {
    rows = await baseQuery.where(
      or(eq(shiftSwapRequests.requesterId, user.id), eq(shiftSwapRequests.counterpartyId, user.id))
    );
  }

  // My upcoming scheduled shifts (for creating a new request)
  const myAssignments = await db
    .select({ id: rosterAssignments.id, date: rosterAssignments.date, shiftName: shifts.name })
    .from(rosterAssignments)
    .innerJoin(shifts, eq(rosterAssignments.shiftId, shifts.id))
    .where(
      and(
        eq(rosterAssignments.userId, user.id),
        eq(rosterAssignments.status, "SCHEDULED"),
        gte(rosterAssignments.date, new Date().toISOString().slice(0, 10))
      )
    );

  const employees = await listVisibleUsers();

  return (
    <div className="max-w-4xl">
      <header className="mb-6">
        <h1 className="text-2xl font-semibold">Shift Swaps</h1>
        <p className="text-sm mt-1" style={{ color: "var(--ink-soft)" }}>
          Request a swap, respond to incoming requests, or approve swaps for your team.
        </p>
      </header>

      <NewSwapRequestForm
        myAssignments={myAssignments}
        employees={employees
          .filter((e) => e.id !== user.id)
          .map((e) => ({ id: e.id, name: e.name, employeeId: e.employeeId }))}
      />

      <SwapList rows={rows} currentUserId={user.id} currentUserRole={user.role} />
    </div>
  );
}
