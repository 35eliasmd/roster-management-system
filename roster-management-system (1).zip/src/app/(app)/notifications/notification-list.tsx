"use client";

import { useRouter } from "next/navigation";
import { useTransition } from "react";
import { markNotificationRead } from "@/lib/actions/notifications";

interface Item {
  id: number;
  title: string;
  message: string;
  isRead: boolean;
  createdAt: Date;
  type: string;
}

export function NotificationList({ items }: { items: Item[] }) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();

  if (items.length === 0) {
    return (
      <div className="card p-10 text-center">
        <p className="text-sm" style={{ color: "var(--ink-soft)" }}>
          You&apos;re all caught up — no notifications yet.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      {items.map((n) => (
        <div
          key={n.id}
          className="card p-4 flex items-start justify-between gap-4"
          style={!n.isRead ? { borderColor: "var(--amber)" } : undefined}
        >
          <div>
            <p className="text-sm font-medium">{n.title}</p>
            <p className="text-sm mt-0.5" style={{ color: "var(--ink-soft)" }}>
              {n.message}
            </p>
            <p className="text-xs mt-1" style={{ color: "var(--ink-soft)" }}>
              {new Date(n.createdAt).toLocaleString()}
            </p>
          </div>
          {!n.isRead && (
            <button
              disabled={isPending}
              className="text-xs font-medium shrink-0"
              style={{ color: "var(--harbor)" }}
              onClick={() =>
                startTransition(async () => {
                  await markNotificationRead(n.id);
                  router.refresh();
                })
              }
            >
              Mark read
            </button>
          )}
        </div>
      ))}
    </div>
  );
}
