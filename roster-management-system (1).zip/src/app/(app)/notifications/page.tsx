import { listMyNotifications } from "@/lib/actions/notifications";
import { NotificationList } from "./notification-list";

export default async function NotificationsPage() {
  const notifications = await listMyNotifications();

  return (
    <div className="max-w-2xl">
      <header className="mb-6">
        <h1 className="text-2xl font-semibold">Notifications</h1>
        <p className="text-sm mt-1" style={{ color: "var(--ink-soft)" }}>
          Shift assignments, swap updates, and roster changes affecting you.
        </p>
      </header>
      <NotificationList items={notifications} />
    </div>
  );
}
