import { auth } from "@/auth";
import { getDashboardSummary } from "@/lib/actions/reports";
import { StatCard } from "@/components/stat-card";
import Link from "next/link";

export default async function DashboardPage() {
  const session = await auth();
  const user = session!.user;
  const summary = await getDashboardSummary();

  return (
    <div className="max-w-5xl">
      <header className="mb-8">
        <h1 className="text-2xl font-semibold">Welcome back, {user.name.split(" ")[0]}</h1>
        <p className="text-sm mt-1" style={{ color: "var(--ink-soft)" }}>
          Here&apos;s what&apos;s happening with the roster today.
        </p>
      </header>

      {summary.role === "ADMIN" && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <StatCard label="Total Employees" value={summary.totalEmployees} />
          <StatCard label="Total Leaders" value={summary.totalLeaders} />
          <StatCard label="Today's Assigned Shifts" value={summary.todayShifts} />
          <StatCard label="Pending Swap Requests" value={summary.pendingSwaps} accent="amber" />
        </div>
      )}

      {summary.role === "LEADER" && (
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-8">
          <StatCard label="Your Subordinates" value={summary.subordinateCount} />
          <StatCard label="Today's Shifts (Team)" value={summary.todayShifts} />
          <StatCard label="Pending Your Approval" value={summary.pendingApprovals} accent="amber" />
        </div>
      )}

      {summary.role === "USER" && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
          <div className="card p-5">
            <p className="text-sm font-medium mb-2" style={{ color: "var(--ink-soft)" }}>
              Today&apos;s Shift
            </p>
            {summary.todayShift ? (
              <p className="text-lg font-semibold">
                {summary.todayShift.shiftName} · {summary.todayShift.startTime}–{summary.todayShift.endTime}
              </p>
            ) : (
              <p className="text-sm" style={{ color: "var(--ink-soft)" }}>
                No shift assigned for today.
              </p>
            )}
          </div>
          <StatCard label="Incoming Swap Requests" value={summary.pendingIncoming} accent="amber" />
        </div>
      )}

      <div className="flex gap-3">
        <Link href="/roster" className="btn-primary">
          View Roster
        </Link>
        <Link href="/swaps" className="btn-secondary">
          Shift Swaps
        </Link>
      </div>
    </div>
  );
}
