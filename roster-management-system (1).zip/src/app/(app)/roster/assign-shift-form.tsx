"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { assignShift } from "@/lib/actions/roster";

interface Employee {
  id: number;
  name: string;
  employeeId: string;
}

export function AssignShiftForm({
  employees,
  shifts,
}: {
  employees: Employee[];
  shifts: { id: number; name: string }[];
}) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [userId, setUserId] = useState("");
  const [shiftId, setShiftId] = useState("");
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [error, setError] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();

  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!userId || !shiftId || !date) return;
    setError(null);
    startTransition(async () => {
      try {
        await assignShift({ userId: Number(userId), shiftId: Number(shiftId), date });
        setOpen(false);
        setUserId("");
        setShiftId("");
        router.refresh();
      } catch (err) {
        setError(err instanceof Error ? err.message : "Failed to assign shift.");
      }
    });
  }

  if (!open) {
    return (
      <button className="btn-primary mb-6" onClick={() => setOpen(true)}>
        + Assign shift
      </button>
    );
  }

  return (
    <form onSubmit={submit} className="card p-4 mb-6 flex flex-wrap gap-3 items-end">
      <div>
        <label className="block text-xs font-medium mb-1" style={{ color: "var(--ink-soft)" }}>
          Employee
        </label>
        <select required value={userId} onChange={(e) => setUserId(e.target.value)} className="input">
          <option value="">Select employee</option>
          {employees.map((e) => (
            <option key={e.id} value={e.id}>
              {e.name} (#{e.employeeId})
            </option>
          ))}
        </select>
      </div>
      <div>
        <label className="block text-xs font-medium mb-1" style={{ color: "var(--ink-soft)" }}>
          Shift
        </label>
        <select required value={shiftId} onChange={(e) => setShiftId(e.target.value)} className="input">
          <option value="">Select shift</option>
          {shifts.map((s) => (
            <option key={s.id} value={s.id}>
              {s.name}
            </option>
          ))}
        </select>
      </div>
      <div>
        <label className="block text-xs font-medium mb-1" style={{ color: "var(--ink-soft)" }}>
          Date
        </label>
        <input required type="date" value={date} onChange={(e) => setDate(e.target.value)} className="input" />
      </div>
      <button type="submit" disabled={isPending} className="btn-primary">
        {isPending ? "Assigning..." : "Assign"}
      </button>
      <button type="button" className="btn-secondary" onClick={() => setOpen(false)}>
        Cancel
      </button>
      {error && (
        <p className="w-full text-sm" style={{ color: "var(--rust)" }}>
          {error}
        </p>
      )}
    </form>
  );
}
