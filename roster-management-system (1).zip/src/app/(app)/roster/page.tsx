import { getRoster } from "@/lib/actions/roster";
import { listShifts } from "@/lib/actions/shifts";
import { listVisibleUsers } from "@/lib/actions/users";
import { RosterFilters } from "./roster-filters";
import { RosterTable } from "./roster-table";
import { AssignShiftForm } from "./assign-shift-form";
import { auth } from "@/auth";

export default async function RosterPage({
  searchParams,
}: {
  searchParams: Promise<{ from?: string; to?: string; q?: string; shiftId?: string }>;
}) {
  const sp = await searchParams;
  const session = await auth();
  const user = session!.user;

  const today = new Date().toISOString().slice(0, 10);
  const from = sp.from || today;
  const to = sp.to || today;

  const [rows, shifts] = await Promise.all([
    getRoster({
      from,
      to,
      employeeSearch: sp.q,
      shiftId: sp.shiftId ? Number(sp.shiftId) : undefined,
    }),
    listShifts(),
  ]);

  return (
    <div>
      <header className="mb-6">
        <h1 className="text-2xl font-semibold">Roster</h1>
        <p className="text-sm mt-1" style={{ color: "var(--ink-soft)" }}>
          {user.role === "ADMIN"
            ? "Viewing all employees across the organization."
            : user.role === "LEADER"
            ? "Viewing your subordinates' schedules."
            : "Viewing your team's schedule."}
        </p>
      </header>

      {(user.role === "ADMIN" || user.role === "LEADER") && (
        <AssignShiftFormLoader shifts={shifts} />
      )}

      <RosterFilters shifts={shifts} defaults={{ from, to, q: sp.q, shiftId: sp.shiftId }} />
      <RosterTable rows={rows} canManage={user.role === "ADMIN" || user.role === "LEADER"} shifts={shifts} />
    </div>
  );
}

async function AssignShiftFormLoader({ shifts }: { shifts: { id: number; name: string }[] }) {
  const employees = await listVisibleUsers();
  return (
    <AssignShiftForm
      employees={employees.map((e) => ({ id: e.id, name: e.name, employeeId: e.employeeId }))}
      shifts={shifts}
    />
  );
}
