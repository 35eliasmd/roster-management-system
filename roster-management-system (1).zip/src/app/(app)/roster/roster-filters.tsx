"use client";

import { useRouter, usePathname } from "next/navigation";
import { useState } from "react";

export function RosterFilters({
  shifts,
  defaults,
}: {
  shifts: { id: number; name: string }[];
  defaults: { from: string; to: string; q?: string; shiftId?: string };
}) {
  const router = useRouter();
  const pathname = usePathname();
  const [from, setFrom] = useState(defaults.from);
  const [to, setTo] = useState(defaults.to);
  const [q, setQ] = useState(defaults.q || "");
  const [shiftId, setShiftId] = useState(defaults.shiftId || "");

  function apply() {
    const params = new URLSearchParams();
    if (from) params.set("from", from);
    if (to) params.set("to", to);
    if (q) params.set("q", q);
    if (shiftId) params.set("shiftId", shiftId);
    router.push(`${pathname}?${params.toString()}`);
  }

  return (
    <div className="card p-4 mb-6 flex flex-wrap gap-3 items-end">
      <div>
        <label className="block text-xs font-medium mb-1" style={{ color: "var(--ink-soft)" }}>
          From date
        </label>
        <input type="date" value={from} onChange={(e) => setFrom(e.target.value)} className="input" />
      </div>
      <div>
        <label className="block text-xs font-medium mb-1" style={{ color: "var(--ink-soft)" }}>
          To date
        </label>
        <input type="date" value={to} onChange={(e) => setTo(e.target.value)} className="input" />
      </div>
      <div>
        <label className="block text-xs font-medium mb-1" style={{ color: "var(--ink-soft)" }}>
          Shift
        </label>
        <select value={shiftId} onChange={(e) => setShiftId(e.target.value)} className="input">
          <option value="">All shifts</option>
          {shifts.map((s) => (
            <option key={s.id} value={s.id}>
              {s.name}
            </option>
          ))}
        </select>
      </div>
      <div className="flex-1 min-w-[180px]">
        <label className="block text-xs font-medium mb-1" style={{ color: "var(--ink-soft)" }}>
          Employee name or ID
        </label>
        <input
          type="text"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search..."
          className="input w-full"
        />
      </div>
      <button onClick={apply} className="btn-primary">
        Apply filters
      </button>
    </div>
  );
}
