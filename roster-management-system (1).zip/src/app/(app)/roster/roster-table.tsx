"use client";

import { useState, useTransition } from "react";
import { updateRosterAssignment, cancelRosterAssignment } from "@/lib/actions/roster";
import { useRouter } from "next/navigation";

interface Row {
  id: number;
  date: string;
  status: string;
  employeeId: string;
  employeeName: string;
  shiftId: number;
  shiftName: string;
  shiftCode: string;
  startTime: string;
  endTime: string;
  colorHex: string | null;
}

export function RosterTable({
  rows,
  canManage,
  shifts,
}: {
  rows: Row[];
  canManage: boolean;
  shifts: { id: number; name: string }[];
}) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [editingId, setEditingId] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);

  const sorted = [...rows].sort((a, b) => a.date.localeCompare(b.date) || a.employeeName.localeCompare(b.employeeName));

  function handleChangeShift(assignmentId: number, newShiftId: number) {
    setError(null);
    startTransition(async () => {
      try {
        await updateRosterAssignment({ assignmentId, newShiftId });
        setEditingId(null);
        router.refresh();
      } catch (e) {
        setError(e instanceof Error ? e.message : "Failed to update shift.");
      }
    });
  }

  function handleCancel(assignmentId: number) {
    if (!confirm("Cancel this shift assignment?")) return;
    setError(null);
    startTransition(async () => {
      try {
        await cancelRosterAssignment(assignmentId);
        router.refresh();
      } catch (e) {
        setError(e instanceof Error ? e.message : "Failed to cancel shift.");
      }
    });
  }

  if (sorted.length === 0) {
    return (
      <div className="card p-10 text-center">
        <p className="text-sm" style={{ color: "var(--ink-soft)" }}>
          No roster entries match your filters.
        </p>
      </div>
    );
  }

  return (
    <div className="card overflow-hidden">
      {error && (
        <p className="px-4 py-2 text-sm" style={{ background: "var(--rust-soft)", color: "var(--rust)" }}>
          {error}
        </p>
      )}
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b" style={{ borderColor: "var(--line)" }}>
            <th className="text-left px-4 py-3 font-medium" style={{ color: "var(--ink-soft)" }}>Date</th>
            <th className="text-left px-4 py-3 font-medium" style={{ color: "var(--ink-soft)" }}>Employee</th>
            <th className="text-left px-4 py-3 font-medium" style={{ color: "var(--ink-soft)" }}>Shift</th>
            <th className="text-left px-4 py-3 font-medium" style={{ color: "var(--ink-soft)" }}>Time</th>
            <th className="text-left px-4 py-3 font-medium" style={{ color: "var(--ink-soft)" }}>Status</th>
            {canManage && <th className="text-right px-4 py-3 font-medium" style={{ color: "var(--ink-soft)" }}>Actions</th>}
          </tr>
        </thead>
        <tbody>
          {sorted.map((r) => (
            <tr key={r.id} className="border-b last:border-0" style={{ borderColor: "var(--line)" }}>
              <td className="px-4 py-3 whitespace-nowrap">{r.date}</td>
              <td className="px-4 py-3">
                <span className="font-medium">{r.employeeName}</span>
                <span className="ml-1 text-xs" style={{ color: "var(--ink-soft)" }}>
                  #{r.employeeId}
                </span>
              </td>
              <td className="px-4 py-3">
                {editingId === r.id ? (
                  <select
                    autoFocus
                    defaultValue={r.shiftId}
                    disabled={isPending}
                    onChange={(e) => handleChangeShift(r.id, Number(e.target.value))}
                    onBlur={() => setEditingId(null)}
                    className="input"
                  >
                    {shifts.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name}
                      </option>
                    ))}
                  </select>
                ) : (
                  <span
                    className="badge"
                    style={{ background: (r.colorHex || "#1e3a4c") + "22", color: r.colorHex || "var(--harbor)" }}
                  >
                    {r.shiftName}
                  </span>
                )}
              </td>
              <td className="px-4 py-3 whitespace-nowrap" style={{ color: "var(--ink-soft)" }}>
                {r.startTime}–{r.endTime}
              </td>
              <td className="px-4 py-3">
                <span
                  className="badge"
                  style={
                    r.status === "SCHEDULED"
                      ? { background: "var(--teal-soft)", color: "var(--teal)" }
                      : { background: "var(--rust-soft)", color: "var(--rust)" }
                  }
                >
                  {r.status}
                </span>
              </td>
              {canManage && (
                <td className="px-4 py-3 text-right whitespace-nowrap">
                  <button
                    className="text-xs font-medium mr-3"
                    style={{ color: "var(--harbor)" }}
                    onClick={() => setEditingId(r.id)}
                    disabled={isPending || r.status !== "SCHEDULED"}
                  >
                    Change shift
                  </button>
                  <button
                    className="text-xs font-medium"
                    style={{ color: "var(--rust)" }}
                    onClick={() => handleCancel(r.id)}
                    disabled={isPending || r.status !== "SCHEDULED"}
                  >
                    Cancel
                  </button>
                </td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
