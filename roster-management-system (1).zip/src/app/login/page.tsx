import { Suspense } from "react";
import { LoginForm } from "./login-form";

export default function LoginPage() {
  return (
    <div className="min-h-screen flex items-center justify-center px-4" style={{ background: "var(--harbor-deep)" }}>
      <div className="w-full max-w-sm">
        <div className="mb-8 text-center">
          <div
            className="inline-flex items-center justify-center w-11 h-11 rounded-lg mb-4"
            style={{ background: "var(--amber)" }}
          >
            <span className="text-white font-bold text-lg">R</span>
          </div>
          <h1 className="text-white text-xl font-semibold">Roster Management</h1>
          <p className="text-sm mt-1" style={{ color: "#94a3b8" }}>
            Sign in to view your schedule and manage duty rosters
          </p>
        </div>
        <div className="card p-6">
          <Suspense fallback={null}>
            <LoginForm />
          </Suspense>
        </div>
      </div>
    </div>
  );
}
