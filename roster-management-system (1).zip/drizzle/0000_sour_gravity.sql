CREATE TYPE "public"."account_status" AS ENUM('ACTIVE', 'INACTIVE', 'SUSPENDED');--> statement-breakpoint
CREATE TYPE "public"."assignment_status" AS ENUM('SCHEDULED', 'CANCELLED', 'COMPLETED');--> statement-breakpoint
CREATE TYPE "public"."notification_type" AS ENUM('SWAP_REQUESTED', 'SWAP_COUNTERPARTY_ACCEPTED', 'SWAP_COUNTERPARTY_REJECTED', 'SWAP_LEADER_APPROVED', 'SWAP_LEADER_REJECTED', 'ROSTER_CHANGED', 'SHIFT_ASSIGNED', 'SHIFT_CANCELLED', 'SYSTEM');--> statement-breakpoint
CREATE TYPE "public"."role" AS ENUM('ADMIN', 'LEADER', 'USER');--> statement-breakpoint
CREATE TYPE "public"."swap_status" AS ENUM('PENDING_COUNTERPARTY', 'PENDING_LEADER', 'APPROVED', 'REJECTED_BY_COUNTERPARTY', 'REJECTED_BY_LEADER', 'CANCELLED');--> statement-breakpoint
CREATE TABLE "audit_logs" (
	"id" serial PRIMARY KEY NOT NULL,
	"actor_id" integer,
	"action" varchar(80) NOT NULL,
	"entity_type" varchar(40) NOT NULL,
	"entity_id" integer,
	"previous_value" jsonb,
	"new_value" jsonb,
	"description" text,
	"ip_address" varchar(64),
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "lobs" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" varchar(120) NOT NULL,
	"code" varchar(40) NOT NULL,
	"description" text,
	"is_active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "notifications" (
	"id" serial PRIMARY KEY NOT NULL,
	"user_id" integer NOT NULL,
	"type" "notification_type" NOT NULL,
	"title" varchar(200) NOT NULL,
	"message" text NOT NULL,
	"is_read" boolean DEFAULT false NOT NULL,
	"related_swap_id" integer,
	"related_assignment_id" integer,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "roster_assignments" (
	"id" serial PRIMARY KEY NOT NULL,
	"user_id" integer NOT NULL,
	"shift_id" integer NOT NULL,
	"date" date NOT NULL,
	"status" "assignment_status" DEFAULT 'SCHEDULED' NOT NULL,
	"notes" text,
	"assigned_by_id" integer,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "roster_history" (
	"id" serial PRIMARY KEY NOT NULL,
	"assignment_id" integer,
	"user_id" integer NOT NULL,
	"date" date NOT NULL,
	"previous_shift_id" integer,
	"new_shift_id" integer,
	"change_type" varchar(40) NOT NULL,
	"changed_by_id" integer NOT NULL,
	"reason" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "shift_swap_requests" (
	"id" serial PRIMARY KEY NOT NULL,
	"requester_id" integer NOT NULL,
	"requester_assignment_id" integer NOT NULL,
	"counterparty_id" integer NOT NULL,
	"counterparty_assignment_id" integer NOT NULL,
	"status" "swap_status" DEFAULT 'PENDING_COUNTERPARTY' NOT NULL,
	"reason" text,
	"counterparty_responded_at" timestamp with time zone,
	"counterparty_responded_by_id" integer,
	"leader_id" integer,
	"leader_responded_at" timestamp with time zone,
	"leader_responded_by_id" integer,
	"leader_comment" text,
	"is_admin_override" boolean DEFAULT false NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "shifts" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" varchar(120) NOT NULL,
	"code" varchar(20) NOT NULL,
	"start_time" time NOT NULL,
	"end_time" time NOT NULL,
	"color_hex" varchar(12) DEFAULT '#2563eb',
	"is_overnight" boolean DEFAULT false NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	"description" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "system_settings" (
	"id" serial PRIMARY KEY NOT NULL,
	"key" varchar(120) NOT NULL,
	"value" jsonb NOT NULL,
	"description" text,
	"updated_by_id" integer,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "users" (
	"id" serial PRIMARY KEY NOT NULL,
	"employee_id" varchar(40) NOT NULL,
	"name" varchar(160) NOT NULL,
	"email" varchar(200) NOT NULL,
	"password_hash" text NOT NULL,
	"role" "role" DEFAULT 'USER' NOT NULL,
	"lob_id" integer,
	"reporting_leader_id" integer,
	"status" "account_status" DEFAULT 'ACTIVE' NOT NULL,
	"phone" varchar(40),
	"designation" varchar(120),
	"join_date" date,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "audit_logs" ADD CONSTRAINT "audit_logs_actor_id_users_id_fk" FOREIGN KEY ("actor_id") REFERENCES "public"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "notifications" ADD CONSTRAINT "notifications_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "notifications" ADD CONSTRAINT "notifications_related_swap_id_shift_swap_requests_id_fk" FOREIGN KEY ("related_swap_id") REFERENCES "public"."shift_swap_requests"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "notifications" ADD CONSTRAINT "notifications_related_assignment_id_roster_assignments_id_fk" FOREIGN KEY ("related_assignment_id") REFERENCES "public"."roster_assignments"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "roster_assignments" ADD CONSTRAINT "roster_assignments_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "roster_assignments" ADD CONSTRAINT "roster_assignments_shift_id_shifts_id_fk" FOREIGN KEY ("shift_id") REFERENCES "public"."shifts"("id") ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "roster_assignments" ADD CONSTRAINT "roster_assignments_assigned_by_id_users_id_fk" FOREIGN KEY ("assigned_by_id") REFERENCES "public"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "roster_history" ADD CONSTRAINT "roster_history_assignment_id_roster_assignments_id_fk" FOREIGN KEY ("assignment_id") REFERENCES "public"."roster_assignments"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "roster_history" ADD CONSTRAINT "roster_history_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "roster_history" ADD CONSTRAINT "roster_history_previous_shift_id_shifts_id_fk" FOREIGN KEY ("previous_shift_id") REFERENCES "public"."shifts"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "roster_history" ADD CONSTRAINT "roster_history_new_shift_id_shifts_id_fk" FOREIGN KEY ("new_shift_id") REFERENCES "public"."shifts"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "roster_history" ADD CONSTRAINT "roster_history_changed_by_id_users_id_fk" FOREIGN KEY ("changed_by_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "shift_swap_requests" ADD CONSTRAINT "shift_swap_requests_requester_id_users_id_fk" FOREIGN KEY ("requester_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "shift_swap_requests" ADD CONSTRAINT "shift_swap_requests_requester_assignment_id_roster_assignments_id_fk" FOREIGN KEY ("requester_assignment_id") REFERENCES "public"."roster_assignments"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "shift_swap_requests" ADD CONSTRAINT "shift_swap_requests_counterparty_id_users_id_fk" FOREIGN KEY ("counterparty_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "shift_swap_requests" ADD CONSTRAINT "shift_swap_requests_counterparty_assignment_id_roster_assignments_id_fk" FOREIGN KEY ("counterparty_assignment_id") REFERENCES "public"."roster_assignments"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "shift_swap_requests" ADD CONSTRAINT "shift_swap_requests_counterparty_responded_by_id_users_id_fk" FOREIGN KEY ("counterparty_responded_by_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "shift_swap_requests" ADD CONSTRAINT "shift_swap_requests_leader_id_users_id_fk" FOREIGN KEY ("leader_id") REFERENCES "public"."users"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "shift_swap_requests" ADD CONSTRAINT "shift_swap_requests_leader_responded_by_id_users_id_fk" FOREIGN KEY ("leader_responded_by_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "system_settings" ADD CONSTRAINT "system_settings_updated_by_id_users_id_fk" FOREIGN KEY ("updated_by_id") REFERENCES "public"."users"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "users" ADD CONSTRAINT "users_lob_id_lobs_id_fk" FOREIGN KEY ("lob_id") REFERENCES "public"."lobs"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "audit_actor_idx" ON "audit_logs" USING btree ("actor_id");--> statement-breakpoint
CREATE INDEX "audit_entity_idx" ON "audit_logs" USING btree ("entity_type","entity_id");--> statement-breakpoint
CREATE INDEX "audit_created_idx" ON "audit_logs" USING btree ("created_at");--> statement-breakpoint
CREATE UNIQUE INDEX "lobs_code_unique" ON "lobs" USING btree ("code");--> statement-breakpoint
CREATE INDEX "notifications_user_idx" ON "notifications" USING btree ("user_id");--> statement-breakpoint
CREATE INDEX "notifications_read_idx" ON "notifications" USING btree ("is_read");--> statement-breakpoint
CREATE UNIQUE INDEX "roster_user_date_unique" ON "roster_assignments" USING btree ("user_id","date");--> statement-breakpoint
CREATE INDEX "roster_date_idx" ON "roster_assignments" USING btree ("date");--> statement-breakpoint
CREATE INDEX "roster_shift_idx" ON "roster_assignments" USING btree ("shift_id");--> statement-breakpoint
CREATE INDEX "roster_history_user_idx" ON "roster_history" USING btree ("user_id");--> statement-breakpoint
CREATE INDEX "roster_history_date_idx" ON "roster_history" USING btree ("date");--> statement-breakpoint
CREATE INDEX "swap_requester_idx" ON "shift_swap_requests" USING btree ("requester_id");--> statement-breakpoint
CREATE INDEX "swap_counterparty_idx" ON "shift_swap_requests" USING btree ("counterparty_id");--> statement-breakpoint
CREATE INDEX "swap_status_idx" ON "shift_swap_requests" USING btree ("status");--> statement-breakpoint
CREATE UNIQUE INDEX "shifts_code_unique" ON "shifts" USING btree ("code");--> statement-breakpoint
CREATE UNIQUE INDEX "system_settings_key_unique" ON "system_settings" USING btree ("key");--> statement-breakpoint
CREATE UNIQUE INDEX "users_employee_id_unique" ON "users" USING btree ("employee_id");--> statement-breakpoint
CREATE UNIQUE INDEX "users_email_unique" ON "users" USING btree ("email");--> statement-breakpoint
CREATE INDEX "users_lob_idx" ON "users" USING btree ("lob_id");--> statement-breakpoint
CREATE INDEX "users_leader_idx" ON "users" USING btree ("reporting_leader_id");--> statement-breakpoint
CREATE INDEX "users_role_idx" ON "users" USING btree ("role");